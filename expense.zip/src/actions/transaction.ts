"use server";

import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { transaction } from "@/db/schema";
import { auth } from "@/lib/auth";
import { getSupabaseAdmin, supabase } from "@/lib/supabase";
import { eq, and } from "drizzle-orm";
import { z } from "zod";

const transactionSchema = z.object({
    type: z.enum(["income", "expense"]),
    amount: z.number().positive(),
    category: z.string().min(1),
    description: z.string().optional(),
    date: z.string().min(1),
    image: z.string().optional(),
});

async function getSession() {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) {
        throw new Error("Unauthorized");
    }

    return session;
}

export async function createTransaction(formData: FormData) {
    const session = await getSession();

    let imageUrl = formData.get("image") as string;
    const imageFile = formData.get("imageFile") as File;

    if (imageFile && imageFile.size > 0) {
        const fileExt = imageFile.name.split(".").pop();
        const fileName = `transaction-${session.user.id}-${Date.now()}.${fileExt}`;
        const supabaseAdmin = getSupabaseAdmin();

        const { error: uploadError } = await supabaseAdmin.storage
            .from("avatars")
            .upload(fileName, imageFile, {
                cacheControl: "3600",
                upsert: true,
                contentType: imageFile.type,
            });

        if (uploadError) {
            console.error("Supabase Upload Error:", uploadError);
            throw new Error(`Failed to upload image: ${uploadError.message}`);
        }

        const { data } = supabase.storage
            .from("avatars")
            .getPublicUrl(fileName);
        imageUrl = data.publicUrl;
    }

    const data = transactionSchema.parse({
        type: formData.get("type") as string,
        amount: Number(formData.get("amount")),
        category: formData.get("category") as string,
        description: formData.get("description") as string,
        date: formData.get("date") as string,
        image: imageUrl || undefined,
    });

    console.log("Creating transaction with image:", data.image);

    await db.insert(transaction).values({
        userId: session.user.id,
        type: data.type,
        amount: data.amount.toString(),
        category: data.category,
        description: data.description || null,
        date: new Date(data.date),
        image: data.image || null,
    });

    revalidatePath("/dashboard");
    revalidatePath("/income");
    revalidatePath("/expense");
}

export async function updateTransaction(id: string, formData: FormData) {
    const session = await getSession();

    let imageUrl = formData.get("image") as string;
    const imageFile = formData.get("imageFile") as File;

    if (imageFile && imageFile.size > 0) {
        const fileExt = imageFile.name.split(".").pop();
        const fileName = `transaction-${session.user.id}-${Date.now()}.${fileExt}`;
        const supabaseAdmin = getSupabaseAdmin();

        const { error: uploadError } = await supabaseAdmin.storage
            .from("avatars")
            .upload(fileName, imageFile, {
                cacheControl: "3600",
                upsert: true,
                contentType: imageFile.type,
            });

        if (uploadError) {
            console.error("Supabase Upload Error:", uploadError);
            throw new Error(`Failed to upload image: ${uploadError.message}`);
        }

        const { data } = supabase.storage
            .from("avatars")
            .getPublicUrl(fileName);
        imageUrl = data.publicUrl;
    }

    const category = formData.get("category") as string;
    const description = formData.get("description") as string;
    const date = formData.get("date") as string;
    const amount = formData.get("amount");

    console.log("Updating transaction:", { id, imageUrl, hasFile: !!(imageFile && imageFile.size > 0) });

    type TransactionUpdate = {
        type: "income" | "expense";
        amount?: string;
        category: string;
        description: string | null;
        date: Date;
        image?: string | null;
    };

    // Build update object dynamically to only update changed/provided fields
    const updateData: TransactionUpdate = {
        type: formData.get("type") as "income" | "expense",
        amount: amount ? Number(amount).toString() : undefined,
        category,
        description: description || null,
        date: new Date(date),
    };

    // Only update image if it was explicitly provided or cleared
    // If imageUrl is empty string and no file, it means it was cleared
    if (imageFile && imageFile.size > 0) {
        updateData.image = imageUrl;
    } else if (imageUrl && imageUrl.startsWith("http")) {
        updateData.image = imageUrl;
    } else if (imageUrl === "") {
        updateData.image = null;
    }

    await db
        .update(transaction)
        .set(updateData)
        .where(
            and(eq(transaction.id, id), eq(transaction.userId, session.user.id))
        );

    revalidatePath("/dashboard");
    revalidatePath("/income");
    revalidatePath("/expense");
}

export async function deleteTransaction(id: string) {
    const session = await getSession();

    await db
        .delete(transaction)
        .where(
            and(eq(transaction.id, id), eq(transaction.userId, session.user.id))
        );

    revalidatePath("/dashboard");
    revalidatePath("/income");
    revalidatePath("/expense");
}

import { getTransactionsForExport, type DateFilter } from "@/queries/transactions";

export async function exportTransactions(
    type: "income" | "expense" | "all",
    filter: DateFilter = "all",
    category?: string,
    search?: string,
    startDate?: string,
    endDate?: string
) {
    const session = await getSession();

    return getTransactionsForExport(
        session.user.id,
        type,
        filter,
        category,
        search,
        startDate ? new Date(startDate) : undefined,
        endDate ? new Date(endDate) : undefined
    );
}
