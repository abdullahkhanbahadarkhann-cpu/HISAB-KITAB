"use server";

import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { user } from "@/db/schema";
import { auth } from "@/lib/auth";
import { getSupabaseAdmin, supabase } from "@/lib/supabase";
import { eq } from "drizzle-orm";

async function getSession() {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) {
        throw new Error("Unauthorized");
    }

    return session;
}

export async function updateProfile(formData: FormData) {
    const session = await getSession();
    const name = formData.get("name") as string;

    if (!name || name.trim().length === 0) {
        throw new Error("Name is required");
    }

    await db
        .update(user)
        .set({ name: name.trim(), updatedAt: new Date() })
        .where(eq(user.id, session.user.id));

    revalidatePath("/settings");
    revalidatePath("/dashboard");
}

export async function updatePassword(formData: FormData) {
    const currentPassword = formData.get("currentPassword") as string;
    const newPassword = formData.get("newPassword") as string;

    if (!currentPassword || !newPassword) {
        throw new Error("Both passwords are required");
    }

    if (newPassword.length < 8) {
        throw new Error("Password must be at least 8 characters");
    }

    await auth.api.changePassword({
        headers: await headers(),
        body: {
            currentPassword,
            newPassword,
        },
    });

    revalidatePath("/settings");
}

export async function uploadProfileImage(formData: FormData) {
    const session = await getSession();
    const file = formData.get("file") as File;

    if (!file) {
        throw new Error("No file provided");
    }

    const fileExt = file.name.split(".").pop();
    const fileName = `${session.user.id}-${Date.now()}.${fileExt}`;

    const supabaseAdmin = getSupabaseAdmin();

    const { error: uploadError } = await supabaseAdmin.storage
        .from("avatars")
        .upload(fileName, file, {
            cacheControl: "3600",
            upsert: true,
            contentType: file.type,
        });

    if (uploadError) {
        console.error("Upload error:", uploadError);
        throw new Error("Failed to upload image");
    }

    const { data: urlData } = supabase.storage
        .from("avatars")
        .getPublicUrl(fileName);

    await db
        .update(user)
        .set({ image: urlData.publicUrl, updatedAt: new Date() })
        .where(eq(user.id, session.user.id));

    revalidatePath("/settings");
    revalidatePath("/dashboard");
}
