"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { updateProfile, updatePassword, uploadProfileImage } from "@/actions/user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Loader2, Camera, User, Lock } from "lucide-react";

interface SettingsFormProps {
    user: {
        id: string;
        name: string;
        email: string;
        image?: string | null;
    };
}

export function SettingsForm({ user }: SettingsFormProps) {
    const router = useRouter();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [profileLoading, setProfileLoading] = useState(false);
    const [passwordLoading, setPasswordLoading] = useState(false);
    const [imageLoading, setImageLoading] = useState(false);

    const initials = user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);

    const handleProfileUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setProfileLoading(true);

        try {
            const formData = new FormData(e.currentTarget);
            await updateProfile(formData);
            toast.success("Profile updated");
            router.refresh();
        } catch {
            toast.error("Failed to update profile");
        } finally {
            setProfileLoading(false);
        }
    };

    const handlePasswordUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setPasswordLoading(true);

        try {
            const formData = new FormData(e.currentTarget);

            if (formData.get("newPassword") !== formData.get("confirmPassword")) {
                toast.error("Passwords do not match");
                setPasswordLoading(false);
                return;
            }

            await updatePassword(formData);
            toast.success("Password updated");
            (e.target as HTMLFormElement).reset();
        } catch {
            toast.error("Failed to update password");
        } finally {
            setPasswordLoading(false);
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setImageLoading(true);

        try {
            const formData = new FormData();
            formData.append("file", file);
            await uploadProfileImage(formData);
            toast.success("Profile image updated");
            router.refresh();
        } catch {
            toast.error("Failed to upload image");
        } finally {
            setImageLoading(false);
        }
    };

    return (
        <div className="space-y-6 max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                <div className="md:col-span-2 space-y-4">
                    <Card className="border border-border shadow-none rounded-xl overflow-hidden bg-card">
                        <CardHeader className="pb-4">
                            <CardTitle className="text-sm font-black uppercase tracking-widest flex items-center gap-2">
                                <User className="h-3.5 w-3.5 text-zinc-400" />
                                Account Profile
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="flex flex-col items-center justify-center p-4 bg-muted/30 rounded-xl border border-dashed border-border">
                                <div className="relative group">
                                    <Avatar className="h-24 w-24 border-2 border-background shadow-xl">
                                        <AvatarImage src={user.image || undefined} alt={user.name} />
                                        <AvatarFallback className="bg-zinc-950 text-white dark:bg-zinc-100 dark:text-zinc-900 text-xl font-black">
                                            {initials}
                                        </AvatarFallback>
                                    </Avatar>
                                    <button
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        disabled={imageLoading}
                                        className="absolute inset-0 flex items-center justify-center rounded-full bg-black/60 opacity-0 group-hover:opacity-100 transition-all duration-300 cursor-pointer backdrop-blur-sm"
                                    >
                                        {imageLoading ? (
                                            <Loader2 className="h-6 w-6 text-white animate-spin" />
                                        ) : (
                                            <Camera className="h-6 w-6 text-white" />
                                        )}
                                    </button>
                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        accept="image/*"
                                        onChange={handleImageUpload}
                                        className="hidden"
                                    />
                                </div>
                                <div className="mt-4 text-center">
                                    <p className="text-sm font-black tracking-tight">{user.name}</p>
                                    <p className="text-[10px] text-muted-foreground font-bold tracking-wider uppercase opacity-60 mt-0.5">{user.email}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <div className="p-4 bg-zinc-950 dark:bg-zinc-100 rounded-xl text-white dark:text-zinc-950 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform duration-500">
                            <User className="h-20 w-20" />
                        </div>
                        <p className="text-[10px] font-black tracking-[0.2em] uppercase text-zinc-500 mb-1">Status</p>
                        <p className="text-xs font-bold flex items-center gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            Active Pro Account
                        </p>
                    </div>
                </div>

                <Card className="md:col-span-3 border border-border shadow-none rounded-xl overflow-hidden bg-card">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-sm font-black uppercase tracking-widest">
                            Personal Details
                        </CardTitle>
                        <CardDescription className="text-[10px] uppercase font-semibold tracking-wider opacity-60">Update your account identity</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleProfileUpdate} className="space-y-4">
                            <div className="space-y-1.5">
                                <Label htmlFor="name" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Full Name</Label>
                                <Input
                                    id="name"
                                    name="name"
                                    defaultValue={user.name}
                                    required
                                    className="h-9 text-xs rounded-lg border-border/60 bg-muted/20"
                                />
                            </div>

                            <div className="space-y-1.5">
                                <Label htmlFor="email-display" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Email Address</Label>
                                <Input
                                    id="email-display"
                                    value={user.email}
                                    disabled
                                    className="h-9 text-xs rounded-lg border-border/60 bg-muted/60 opacity-60 italic"
                                />
                            </div>

                            <div className="pt-2">
                                <Button
                                    type="submit"
                                    disabled={profileLoading}
                                    className="bg-zinc-950 dark:bg-zinc-50 text-white dark:text-zinc-900 rounded-lg h-8 text-[10px] font-black uppercase tracking-wider px-6 transition-all active:scale-95 shadow-lg shadow-zinc-500/10"
                                >
                                    {profileLoading ? (
                                        <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                                    ) : null}
                                    Save Changes
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </div>

            <Card className="border border-border shadow-none rounded-xl overflow-hidden bg-card">
                <CardHeader className="pb-4 border-b border-border/50 bg-muted/10">
                    <CardTitle className="text-sm font-black uppercase tracking-widest flex items-center gap-2">
                        <Lock className="h-3.5 w-3.5 text-zinc-400" />
                        Security Credentials
                    </CardTitle>
                    <CardDescription className="text-[10px] uppercase font-semibold tracking-wider opacity-60">Maintain a secure access password</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                    <form onSubmit={handlePasswordUpdate} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="space-y-1.5">
                                <Label htmlFor="currentPassword" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Current Password</Label>
                                <Input
                                    id="currentPassword"
                                    name="currentPassword"
                                    type="password"
                                    required
                                    placeholder="••••••••"
                                    className="h-9 text-xs rounded-lg border-border/60 bg-muted/20"
                                />
                            </div>

                            <div className="space-y-1.5">
                                <Label htmlFor="newPassword" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">New Password</Label>
                                <Input
                                    id="newPassword"
                                    name="newPassword"
                                    type="password"
                                    required
                                    minLength={8}
                                    placeholder="••••••••"
                                    className="h-9 text-xs rounded-lg border-border/60 bg-muted/20"
                                />
                            </div>

                            <div className="space-y-1.5">
                                <Label htmlFor="confirmPassword" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Confirm New</Label>
                                <Input
                                    id="confirmPassword"
                                    name="confirmPassword"
                                    type="password"
                                    required
                                    minLength={8}
                                    placeholder="••••••••"
                                    className="h-9 text-xs rounded-lg border-border/60 bg-muted/20"
                                />
                            </div>
                        </div>

                        <div className="pt-2 border-t border-border/50">
                            <Button
                                type="submit"
                                disabled={passwordLoading}
                                variant="outline"
                                className="rounded-lg h-8 text-[10px] font-black uppercase tracking-wider px-6 transition-all active:scale-95 border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 shadow-sm"
                            >
                                {passwordLoading ? (
                                    <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                                ) : null}
                                Update Password
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
