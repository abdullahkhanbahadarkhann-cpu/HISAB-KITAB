import { Card, CardContent } from "@/components/ui/card";
import { cn, formatCurrency } from "@/lib/utils";
import { TrendingUp, TrendingDown, Wallet } from "lucide-react";

interface SummaryCardProps {
    label: string;
    income: number;
    expense: number;
    balance: number;
    isActive?: boolean;
}

export function SummaryCard({ label, income, expense, balance, isActive }: SummaryCardProps) {
    const isPositive = balance >= 0;

    return (
        <Card
            className={cn(
                "transition-all duration-200 border border-border shadow-none",
                isActive
                    ? "bg-zinc-950 text-white dark:bg-zinc-100 dark:text-zinc-900 border-transparent shadow-md"
                    : "bg-white dark:bg-zinc-900/50 hover:bg-zinc-50 dark:hover:bg-zinc-900"
            )}
        >
            <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                    <span
                        className={cn(
                            "text-[10px] font-bold uppercase tracking-[0.1em]",
                            isActive ? "text-white/60 dark:text-zinc-900/60" : "text-muted-foreground/60"
                        )}
                    >
                        {label}
                    </span>
                    <div
                        className={cn(
                            "flex h-6 w-6 items-center justify-center rounded-md border",
                            isActive ? "bg-white/10 border-white/10" : "bg-muted/50 border-border/50"
                        )}
                    >
                        <Wallet className={cn("h-3 w-3", isActive ? "text-white dark:text-zinc-900" : "text-muted-foreground")} />
                    </div>
                </div>

                <div className="space-y-4">
                    <div>
                        <p
                            className={cn(
                                "text-xl font-black tracking-tight",
                                isActive ? "text-white dark:text-zinc-900" : isPositive ? "text-foreground" : "text-destructive"
                            )}
                        >
                            {formatCurrency(balance)}
                        </p>
                    </div>

                    <div className="flex items-center gap-3 pt-3 border-t border-border/10">
                        <div className="flex items-center gap-1">
                            <TrendingUp
                                className={cn(
                                    "h-3 w-3",
                                    isActive ? "text-emerald-400" : "text-emerald-500"
                                )}
                            />
                            <span
                                className={cn(
                                    "text-[10px] font-bold",
                                    isActive ? "text-white/80 dark:text-zinc-900/80" : "text-muted-foreground"
                                )}
                            >
                                {formatCurrency(income)}
                            </span>
                        </div>
                        <div className="flex items-center gap-1">
                            <TrendingDown
                                className={cn(
                                    "h-3 w-3",
                                    isActive ? "text-rose-400" : "text-rose-500"
                                )}
                            />
                            <span
                                className={cn(
                                    "text-[10px] font-bold",
                                    isActive ? "text-white/80 dark:text-zinc-900/80" : "text-muted-foreground"
                                )}
                            >
                                {formatCurrency(expense)}
                            </span>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}
