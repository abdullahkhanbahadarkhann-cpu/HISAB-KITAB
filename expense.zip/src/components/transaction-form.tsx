"use client";

import { useState, useId, useRef } from "react";
import { useRouter } from "next/navigation";
import { createTransaction, updateTransaction } from "@/actions/transaction";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogFooter,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, Plus, Pencil, ImageIcon, X } from "lucide-react";
import Image from "next/image";

const incomeCategories = [
    "Salary",
    "Freelance",
    "Investment",
    "Business",
    "Rental",
    "Gift",
    "Other",
];

const expenseCategories = [
    "Food",
    "Transport",
    "Housing",
    "Utilities",
    "Healthcare",
    "Education",
    "Entertainment",
    "Shopping",
    "Insurance",
    "Savings",
    "Other",
];

interface TransactionFormProps {
    type: "income" | "expense";
    transaction?: {
        id: string;
        amount: string;
        category: string;
        description: string | null;
        date: Date;
        image: string | null;
    };
}

export function TransactionForm({ type, transaction: existing }: TransactionFormProps) {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [preview, setPreview] = useState<string | null>(existing?.image || null);
    const fileInputId = useId();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const categories = type === "income" ? incomeCategories : expenseCategories;
    const isEditing = !!existing;

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setLoading(true);

        try {
            const formData = new FormData(e.currentTarget);
            formData.set("type", type);

            if (isEditing) {
                await updateTransaction(existing.id, formData);
                toast.success(`${type === "income" ? "Income" : "Expense"} updated`);
            } else {
                await createTransaction(formData);
                toast.success(`${type === "income" ? "Income" : "Expense"} added`);
            }

            setOpen(false);
            router.refresh();
        } catch {
            toast.error("Something went wrong");
        } finally {
            setLoading(false);
        }
    };

    const defaultDate = existing
        ? new Date(existing.date).toISOString().split("T")[0]
        : new Date().toISOString().split("T")[0];

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                {isEditing ? (
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Pencil className="h-3.5 w-3.5" />
                    </Button>
                ) : (
                    <Button className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-lg shadow-purple-500/25">
                        <Plus className="mr-2 h-4 w-4" />
                        Add {type === "income" ? "Income" : "Expense"}
                    </Button>
                )}
            </DialogTrigger>
            <DialogContent className="sm:max-w-2xl max-h-[90dvh] flex flex-col p-0 overflow-hidden">
                <DialogHeader className="p-6 pb-2 border-b">
                    <DialogTitle>
                        {isEditing ? "Edit" : "Add"} {type === "income" ? "Income" : "Expense"}
                    </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
                    <div className="flex-1 overflow-y-auto p-6 space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="amount">Amount (Rs)</Label>
                            <Input
                                id="amount"
                                name="amount"
                                type="number"
                                step="0.01"
                                min="0"
                                placeholder="0.00"
                                defaultValue={existing?.amount || ""}
                                required
                                className="h-11"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="category">Category</Label>
                            <Select name="category" defaultValue={existing?.category || ""} required>
                                <SelectTrigger className="h-11">
                                    <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                                <SelectContent>
                                    {categories.map((cat) => (
                                        <SelectItem key={cat} value={cat}>
                                            {cat}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="description">Description</Label>
                            <Input
                                id="description"
                                name="description"
                                placeholder="Optional description"
                                defaultValue={existing?.description || ""}
                                className="h-11"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="date">Date</Label>
                            <Input
                                id="date"
                                name="date"
                                type="date"
                                defaultValue={defaultDate}
                                required
                                className="h-11"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label>Attachment (Optional)</Label>
                            <div className="flex flex-col gap-3">
                                {preview ? (
                                    <div className="relative aspect-video w-full overflow-hidden rounded-xl border bg-muted/50">
                                        <Image
                                            src={preview}
                                            alt="Preview"
                                            fill
                                            className="object-cover"
                                        />
                                        <Button
                                            type="button"
                                            variant="destructive"
                                            size="icon"
                                            className="absolute right-2 top-2 h-8 w-8 rounded-full shadow-lg"
                                            onClick={() => {
                                                setPreview(null);
                                                if (fileInputRef.current) fileInputRef.current.value = "";
                                            }}
                                        >
                                            <X className="h-4 w-4" />
                                        </Button>
                                    </div>
                                ) : (
                                    <div
                                        onClick={() => fileInputRef.current?.click()}
                                        className="flex aspect-video w-full cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed bg-muted/30 transition-colors hover:bg-muted/50"
                                    >
                                        <div className="flex flex-col items-center justify-center pb-6 pt-5">
                                            <div className="mb-3 rounded-full bg-violet-500/10 p-3">
                                                <ImageIcon className="h-6 w-6 text-violet-500" />
                                            </div>
                                            <p className="text-sm font-medium">Click to upload receipt</p>
                                            <p className="mt-1 text-xs text-muted-foreground">PNG, JPG or WEBP</p>
                                        </div>
                                    </div>
                                )}
                                <input
                                    ref={fileInputRef}
                                    id={fileInputId}
                                    name="imageFile"
                                    type="file"
                                    className="hidden"
                                    accept="image/*"
                                    onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                            const reader = new FileReader();
                                            reader.onloadend = () => {
                                                setPreview(reader.result as string);
                                            };
                                            reader.readAsDataURL(file);
                                        }
                                    }}
                                />
                                {/* Hidden field to keep track of existing image URL if not changed */}
                                <input type="hidden" name="image" value={preview?.startsWith("http") ? preview : ""} />
                            </div>
                        </div>
                    </div>

                    <DialogFooter className="p-6 border-t bg-muted/20">
                        <div className="flex gap-2 w-full">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => setOpen(false)}
                                className="flex-1"
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                disabled={loading}
                                className="flex-1 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-md"
                            >
                                {loading ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                ) : isEditing ? (
                                    "Update"
                                ) : (
                                    "Add"
                                )}
                            </Button>
                        </div>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
