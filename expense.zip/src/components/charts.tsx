"use client";

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    Legend,
    PieChart,
    Pie,
    Cell,
    AreaChart,
    Area,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

interface ChartData {
    name: string;
    income: number;
    expense: number;
}

interface OverviewChartProps {
    data: ChartData[];
}

export function OverviewChart({ data }: OverviewChartProps) {
    return (
        <Card className="border-0 shadow-xl bg-card/50 backdrop-blur-sm overflow-hidden">
            <CardHeader className="pb-6">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="text-lg font-bold tracking-tight">Financial Overview</CardTitle>
                        <CardDescription>Monthly income and expense comparison</CardDescription>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="h-[350px] w-full mt-4">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <defs>
                                <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="hsl(160, 60%, 45%)" stopOpacity={0.1} />
                                    <stop offset="95%" stopColor="hsl(160, 60%, 45%)" stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0.1} />
                                    <stop offset="95%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted)/0.2)" vertical={false} />
                            <XAxis
                                dataKey="name"
                                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                                axisLine={false}
                                tickLine={false}
                                dy={10}
                            />
                            <YAxis
                                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                                axisLine={false}
                                tickLine={false}
                                tickFormatter={(value) => `${value >= 1000 ? (value / 1000).toFixed(1) + 'k' : value}`}
                            />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: "hsl(var(--background))",
                                    border: "1px solid hsl(var(--border))",
                                    borderRadius: "12px",
                                    boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
                                    fontSize: "12px",
                                    padding: "8px 12px"
                                }}
                                cursor={{ stroke: 'hsl(var(--muted))', strokeWidth: 1 }}
                            />
                            <Legend
                                verticalAlign="top"
                                align="right"
                                iconType="circle"
                                iconSize={8}
                                wrapperStyle={{ paddingBottom: '20px', fontSize: '12px', fontWeight: 500 }}
                            />
                            <Area
                                type="monotone"
                                dataKey="income"
                                name="Income"
                                stroke="hsl(160, 60%, 45%)"
                                strokeWidth={3}
                                strokeLinecap="round"
                                fillOpacity={1}
                                fill="url(#colorIncome)"
                            />
                            <Area
                                type="monotone"
                                dataKey="expense"
                                name="Expense"
                                stroke="hsl(0, 84%, 60%)"
                                strokeWidth={3}
                                strokeLinecap="round"
                                fillOpacity={1}
                                fill="url(#colorExpense)"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
}

const COLORS = [
    "hsl(160, 60%, 45%)", // emerald
    "hsl(0, 84%, 60%)",   // rose
    "hsl(221, 83%, 53%)", // blue
    "hsl(262, 83%, 58%)", // violet
    "hsl(47, 95%, 55%)",  // amber
    "hsl(199, 89%, 48%)", // sky
];

export function CategoryPieChart({ data }: { data: { name: string; value: number }[] }) {
    return (
        <Card className="border-0 shadow-xl bg-card/50 backdrop-blur-sm overflow-hidden h-full">
            <CardHeader className="pb-0">
                <CardTitle className="text-lg font-bold tracking-tight">Spending Breakdown</CardTitle>
                <CardDescription>Distribution by category</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="h-[350px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: "hsl(var(--background))",
                                    border: "1px solid hsl(var(--border))",
                                    borderRadius: "12px",
                                    boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
                                }}
                                formatter={(value: number | undefined) => `Rs ${(value || 0).toLocaleString()}`}
                            />
                            <Legend
                                verticalAlign="bottom"
                                align="center"
                                iconType="circle"
                                iconSize={8}
                                wrapperStyle={{ fontSize: '11px', paddingTop: '20px' }}
                            />
                            <Pie
                                data={data}
                                cx="50%"
                                cy="50%"
                                innerRadius={70}
                                outerRadius={90}
                                paddingAngle={8}
                                dataKey="value"
                                stroke="none"
                            >
                                {data.map((_, index) => (
                                    <Cell
                                        key={`cell-${index}`}
                                        fill={COLORS[index % COLORS.length]}
                                        style={{ filter: `drop-shadow(0px 4px 6px ${COLORS[index % COLORS.length]}20)` }}
                                    />
                                ))}
                            </Pie>
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
}
