"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";

const incomeCategories = [
    "All",
    "Salary",
    "Freelance",
    "Investment",
    "Business",
    "Rental",
    "Gift",
    "Other",
];

const expenseCategories = [
    "All",
    "Food",
    "Transport",
    "Housing",
    "Utilities",
    "Healthcare",
    "Education",
    "Entertainment",
    "Shopping",
    "Insurance",
    "Savings",
    "Other",
];

interface CategoryFilterProps {
    type: "income" | "expense" | "all";
}

export function CategoryFilter({ type }: CategoryFilterProps) {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();
    const currentCategory = searchParams.get("category") || "All";

    const categories = type === "income"
        ? incomeCategories
        : type === "expense"
            ? expenseCategories
            : Array.from(new Set([...incomeCategories, ...expenseCategories]));

    const handleChange = (value: string) => {
        const params = new URLSearchParams(searchParams.toString());
        if (value === "All") {
            params.delete("category");
        } else {
            params.set("category", value);
        }
        router.push(`${pathname}?${params.toString()}`);
    };

    return (
        <Select value={currentCategory} onValueChange={handleChange}>
            <SelectTrigger className="w-[160px] h-9 rounded-xl border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 font-medium text-xs">
                <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent className="rounded-xl border-zinc-200 dark:border-zinc-800 shadow-xl">
                {categories.map((cat) => (
                    <SelectItem key={cat} value={cat} className="text-xs font-medium">
                        {cat}
                    </SelectItem>
                ))}
            </SelectContent>
        </Select>
    );
}
