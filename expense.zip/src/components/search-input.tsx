"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useEffect, useState } from "react";
import { useDebounce } from "@/hooks/use-debounce";

export function SearchInput({ placeholder }: { placeholder: string }) {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();

    // Initialize state with URL param
    const [value, setValue] = useState(searchParams.get("search") || "");
    const debouncedValue = useDebounce(value, 500);

    // Update URL when debounced value changes
    useEffect(() => {
        const currentSearch = searchParams.get("search") || "";

        // Only update if the value has actually changed to avoid infinite loops
        if (debouncedValue === currentSearch) return;

        const params = new URLSearchParams(searchParams.toString());
        if (debouncedValue) {
            params.set("search", debouncedValue);
        } else {
            params.delete("search");
        }

        // Use router.replace to avoid clogging history or push if preferred
        router.push(`${pathname}?${params.toString()}`);
    }, [debouncedValue, pathname, router]); // Remove searchParams from dependencies

    return (
        <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
                type="search"
                placeholder={placeholder}
                className="w-full pl-9 bg-background/50 border-input focus:bg-background transition-colors"
                value={value}
                onChange={(e) => setValue(e.target.value)}
            />
        </div>
    );
}
