"use client";

import { useSearchParams, usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

export function ResetFilters() {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();

    const hasActiveFilters =
        (searchParams.get("filter") && searchParams.get("filter") !== "all") ||
        searchParams.get("category") ||
        searchParams.get("search") ||
        searchParams.get("from") ||
        searchParams.get("to");

    const handleReset = () => {
        router.push(pathname);
    };

    if (!hasActiveFilters) {
        return null;
    }

    return (
        <Button
            variant="outline"
            size="sm"
            onClick={handleReset}
            className="h-8 w-full sm:w-auto px-2 lg:px-3 text-muted-foreground hover:text-foreground"
        >
            <X className="mr-2 h-4 w-4" />
            <span>Reset Filters</span>
        </Button>
    );
}
