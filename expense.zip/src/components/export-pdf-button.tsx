"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { FileDown, Loader2 } from "lucide-react";
import { exportTransactions } from "@/actions/transaction";
import { type DateFilter } from "@/queries/transactions";
import { formatCurrency, formatDate } from "@/lib/utils";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { format } from "date-fns";

interface ExportPdfButtonProps {
    type: "income" | "expense" | "all";
    filter?: DateFilter;
    category?: string;
    search?: string;
    startDate?: string;
    endDate?: string;
    user: {
        name: string;
        email: string;
    };
}

export function ExportPdfButton({
    type,
    filter,
    category,
    search,
    startDate,
    endDate,
    user,
}: ExportPdfButtonProps) {
    const [loading, setLoading] = useState(false);

    const handleExport = async () => {
        setLoading(true);
        try {
            const transactions = await exportTransactions(
                type,
                filter,
                category,
                search,
                startDate,
                endDate
            );

            if (!transactions || transactions.length === 0) {
                toast.error("No transactions found to export");
                setLoading(false);
                return;
            }

            const doc = new jsPDF({
                orientation: "portrait",
                unit: "mm",
                format: "a4",
            });

            const isIncome = type === "income";
            const isExpense = type === "expense";
            const isAll = type === "all";

            const primaryColor: [number, number, number] = isIncome
                ? [16, 185, 129]
                : isExpense
                    ? [239, 68, 68]
                    : [99, 102, 241]; // Violet for "all"

            // --- PAGE 1: HEADER & SUMMARY ---
            // 1. Sleek Header
            doc.setFillColor(248, 250, 252);
            doc.rect(0, 0, 210, 50, "F");

            doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
            doc.rect(0, 0, 3, 50, "F");

            doc.setTextColor(30, 41, 59);
            doc.setFontSize(22);
            doc.setFont("helvetica", "bold");
            doc.text("BANK OF USMAN", 15, 20);

            doc.setFontSize(9);
            doc.setFont("helvetica", "normal");
            doc.setTextColor(100, 116, 139);
            doc.text(`${type.toUpperCase()} STATEMENT`, 15, 27);
            doc.text(`Generated on ${format(new Date(), "PPP p")}`, 15, 32);

            // 2. Account Information
            doc.setTextColor(100, 116, 139);
            doc.setFontSize(7);
            doc.setFont("helvetica", "bold");
            doc.text("ACCOUNT HOLDER", 15, 65);
            doc.text("PERIOD", 85, 65);
            doc.text("STATEMENT TYPE", 155, 65);

            doc.setTextColor(30, 41, 59);
            doc.setFontSize(9);
            doc.setFont("helvetica", "bold");
            doc.text(user.name.toUpperCase(), 15, 71);
            doc.setFontSize(8);
            doc.setFont("helvetica", "normal");
            doc.text(user.email, 15, 76);

            let periodText = "ALL TIME";
            if (filter && filter !== "all") {
                periodText = filter.toUpperCase();
            } else if (startDate && endDate) {
                periodText = `${formatDate(new Date(startDate))} - ${formatDate(new Date(endDate))}`;
            }
            doc.text(periodText, 85, 71);
            doc.text(`${type.toUpperCase()} ACCOUNT`, 155, 71);

            // 3. Statement Summary Box
            doc.setFillColor(252, 253, 254);
            doc.setDrawColor(241, 245, 249);
            doc.roundedRect(15, 85, 180, 25, 2, 2, "FD");

            if (isAll) {
                const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + Number(t.amount), 0);
                const totalExpense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + Number(t.amount), 0);

                doc.setTextColor(100, 116, 139);
                doc.setFontSize(7);
                doc.setFont("helvetica", "bold");
                doc.text("TOTAL INCOME", 22, 93);
                doc.text("TOTAL EXPENSE", 85, 93);
                doc.text("NET BALANCE", 145, 93);

                doc.setTextColor(16, 185, 129);
                doc.setFontSize(12);
                doc.text(formatCurrency(totalIncome), 22, 102);

                doc.setTextColor(239, 68, 68);
                doc.text(formatCurrency(totalExpense), 85, 102);

                const balance = totalIncome - totalExpense;
                if (balance >= 0) {
                    doc.setTextColor(16, 185, 129);
                } else {
                    doc.setTextColor(239, 68, 68);
                }
                doc.text(formatCurrency(balance), 145, 102);
            } else {
                doc.setTextColor(100, 116, 139);
                doc.setFontSize(7);
                doc.setFont("helvetica", "bold");
                doc.text(`TOTAL ${type.toUpperCase()}`, 22, 93);
                doc.text("TRANSACTION COUNT", 145, 93);

                const total = transactions.reduce((sum, t) => sum + Number(t.amount), 0);
                doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
                doc.setFontSize(16);
                doc.setFont("helvetica", "bold");
                doc.text(formatCurrency(total), 22, 102);

                doc.setTextColor(30, 41, 59);
                doc.text(transactions.length.toString(), 145, 102);
            }

            // 4. Enhanced Transaction Table
            const tableHeaders = isAll
                ? [["DATE", "TYPE", "CATEGORY", "DESCRIPTION", "AMOUNT"]]
                : [["DATE", "CATEGORY", "DESCRIPTION", "AMOUNT"]];

            autoTable(doc, {
                startY: 120,
                margin: { left: 15, right: 15 },
                head: tableHeaders,
                body: transactions.map((t) => {
                    const row = [
                        formatDate(t.date),
                    ];
                    if (isAll) row.push(t.type.toUpperCase());
                    row.push(t.category.toUpperCase());
                    row.push(t.description || "N/A");
                    row.push(`${t.type === 'income' ? '+' : '-'}${formatCurrency(Number(t.amount))}`);
                    return row;
                }),
                theme: "plain",
                styles: {
                    fontSize: 7.5,
                    cellPadding: 4,
                    font: "helvetica",
                    textColor: [51, 65, 85],
                },
                headStyles: {
                    fontStyle: "bold",
                    textColor: [148, 163, 184],
                    fontSize: 6.5,
                },
                columnStyles: isAll ? {
                    0: { cellWidth: 30 },
                    1: { cellWidth: 25 },
                    2: { cellWidth: 35, fontStyle: "bold" },
                    3: { cellWidth: "auto" },
                    4: { cellWidth: 35, fontStyle: "bold", halign: "right" }
                } : {
                    0: { cellWidth: 35 },
                    1: { cellWidth: 40, fontStyle: "bold" },
                    2: { cellWidth: "auto" },
                    3: { cellWidth: 35, fontStyle: "bold", halign: "right", textColor: primaryColor }
                },
                didParseCell: (data) => {
                    if (isAll && data.section === 'body' && data.column.index === 4) {
                        const amountText = data.cell.text[0];
                        if (amountText.startsWith('+')) {
                            data.cell.styles.textColor = [16, 185, 129];
                        } else {
                            data.cell.styles.textColor = [239, 68, 68];
                        }
                    }
                },
                didDrawPage: (data) => {
                    // Footer
                    doc.setDrawColor(241, 245, 249);
                    doc.line(15, 280, 195, 280);
                    doc.setFontSize(7);
                    doc.setTextColor(148, 163, 184);
                    doc.text("BANK OF USMAN Financial Statement", 15, 285);
                    doc.setFont("helvetica", "bold");
                    doc.text("Powered by Usman Zafar", 105, 285, { align: "center" });
                    doc.setFont("helvetica", "normal");
                    doc.text(`Page ${data.pageNumber}`, 195, 285, { align: "right" });

                    // Line under header
                    doc.setDrawColor(241, 245, 249);
                    doc.setLineWidth(0.3);
                    doc.line(15, data.cursor?.y || 120, 195, data.cursor?.y || 120);
                },
                willDrawCell: (data) => {
                    if (data.section === "body") {
                        doc.setDrawColor(248, 250, 252);
                        doc.setLineWidth(0.1);
                        doc.line(data.cell.x, data.cell.y + data.cell.height, data.cell.x + data.cell.width, data.cell.y + data.cell.height);
                    }
                }
            });

            doc.save(`HK-Statement-${type}-${new Date().getTime()}.pdf`);
            toast.success("Statement exported successfully!");
        } catch (error) {
            console.error("Failed to export PDF:", error);
            toast.error("Failed to generate statement");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Button
            onClick={handleExport}
            disabled={loading}
            variant="outline"
            className="group relative overflow-hidden h-11 px-6 rounded-2xl border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-all font-bold text-xs gap-2 shadow-sm"
        >
            {loading ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
                <FileDown className="h-3.5 w-3.5 text-zinc-500 group-hover:translate-y-0.5 transition-transform" />
            )}
            <span>Export Statement</span>
        </Button>
    );
}
