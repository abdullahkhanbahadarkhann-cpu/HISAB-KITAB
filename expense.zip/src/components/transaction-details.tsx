"use client";

import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, Calendar, Tag, FileText, Receipt, ExternalLink } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";
import Image from "next/image";

interface TransactionDetailsProps {
    transaction: {
        id: string;
        type: "income" | "expense";
        amount: string;
        category: string;
        description: string | null;
        date: Date;
        image: string | null;
    };
}

export function TransactionDetails({ transaction }: TransactionDetailsProps) {
    const isIncome = transaction.type === "income";

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 rounded-full text-muted-foreground hover:bg-violet-500/10 hover:text-violet-600 transition-colors"
                    title="View Details"
                >
                    <Eye className="h-3.5 w-3.5" />
                </Button>
            </DialogTrigger>
            <DialogContent className="w-full p-0 overflow-hidden rounded-2xl border-none shadow-2xl">
                <DialogHeader className="p-6 bg-gradient-to-br from-violet-600 to-purple-700 text-white">
                    <div className="flex items-center justify-between">
                        <DialogTitle className="text-xl font-bold tracking-tight">
                            Transaction Details
                        </DialogTitle>
                        <Badge className={isIncome ? "bg-emerald-500/20 text-emerald-100 border-none" : "bg-rose-500/20 text-rose-100 border-none"}>
                            {isIncome ? "Income" : "Expense"}
                        </Badge>
                    </div>
                </DialogHeader>

                <div className="p-6 space-y-6 bg-card">
                    {/* Amount & Date Summary */}
                    <div className="flex flex-col items-center justify-center py-4 space-y-1 bg-muted/30 rounded-2xl border border-dashed border-muted-foreground/20">
                        <span className={`text-3xl font-bold tracking-tight ${isIncome ? "text-emerald-600" : "text-rose-600"}`}>
                            {isIncome ? "+" : "-"}{formatCurrency(Number(transaction.amount))}
                        </span>
                        <span className="text-sm text-muted-foreground font-medium">
                            {formatDate(transaction.date)}
                        </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                            <label className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-1.5">
                                <Tag className="h-3 w-3" /> Category
                            </label>
                            <div className="text-sm font-semibold bg-muted/50 px-3 py-2 rounded-lg border">
                                {transaction.category}
                            </div>
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-1.5">
                                <Calendar className="h-3 w-3" /> Date
                            </label>
                            <div className="text-sm font-semibold bg-muted/50 px-3 py-2 rounded-lg border">
                                {formatDate(transaction.date)}
                            </div>
                        </div>
                    </div>

                    <div className="space-y-1.5">
                        <label className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-1.5">
                            <FileText className="h-3 w-3" /> Description
                        </label>
                        <div className="text-sm text-foreground/80 bg-muted/30 px-4 py-3 rounded-xl border leading-relaxed min-h-[60px]">
                            {transaction.description || "No description provided."}
                        </div>
                    </div>

                    {/* Receipt/Image Section */}
                    <div className="space-y-2.5">
                        <label className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-1.5">
                            <Receipt className="h-3 w-3" /> Attachment
                        </label>
                        {transaction.image ? (
                            <div className="relative group overflow-hidden rounded-2xl border bg-muted/20">
                                <div className="aspect-video relative overflow-hidden">
                                    <Image
                                        src={transaction.image}
                                        alt="Receipt"
                                        fill
                                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                                    />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <a
                                            href={transaction.image}
                                            target="_blank"
                                            rel="noreferrer"
                                            className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform"
                                        >
                                            <ExternalLink className="h-3 w-3" />
                                            View Full Size
                                        </a>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="aspect-video rounded-2xl border border-dashed flex flex-col items-center justify-center text-muted-foreground bg-muted/10">
                                <Receipt className="h-8 w-8 mb-2 opacity-20" />
                                <span className="text-xs font-medium italic opacity-50 text-center">No receipt attached</span>
                            </div>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
