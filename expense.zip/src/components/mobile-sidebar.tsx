"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { ThemeToggle } from "@/components/theme-toggle";
import { signOut } from "@/lib/auth-client";
import { useRouter } from "next/navigation";
import {
    LayoutDashboard,
    TrendingUp,
    TrendingDown,
    Settings,
    LogOut,
    Wallet,
    Menu,
    Receipt,
} from "lucide-react";

const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/transactions", label: "Transactions", icon: Receipt },
    { href: "/income", label: "Income", icon: TrendingUp },
    { href: "/expense", label: "Expense", icon: TrendingDown },
    { href: "/settings", label: "Settings", icon: Settings },
];

interface MobileSidebarProps {
    user: {
        name: string;
        email: string;
        image?: string | null;
    };
}

export function MobileSidebar({ user }: MobileSidebarProps) {
    const pathname = usePathname();
    const router = useRouter();

    const handleLogout = async () => {
        await signOut();
        router.push("/login");
        router.refresh();
    };

    const initials = user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);

    return (
        <Sheet>
            <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden h-8 w-8 hover:bg-muted/50 rounded-lg">
                    <Menu className="h-4 w-4" />
                </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[280px] p-0 border-r bg-card shadow-xl">
                <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                <div className="flex h-full flex-col">
                    <div className="flex items-center gap-2.5 px-6 py-8">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-zinc-950 dark:bg-zinc-50 shadow-sm">
                            <Wallet className="h-4 w-4 text-white dark:text-zinc-950" />
                        </div>
                        <div>
                            <h1 className="text-sm font-black tracking-tight leading-none uppercase">HISAB KITAB</h1>
                            <p className="text-[10px] text-muted-foreground font-bold tracking-[0.1em] mt-1 uppercase opacity-60">PRO EDITION</p>
                        </div>
                    </div>

                    <div className="flex-1 space-y-6 px-3 py-2 overflow-y-auto no-scrollbar">
                        <div>
                            <p className="px-4 mb-3 text-[10px] font-bold text-muted-foreground/50 uppercase tracking-[0.15em]">Main Menu</p>
                            <nav className="space-y-1">
                                {navItems.map((item) => {
                                    const isActive = pathname === item.href;
                                    return (
                                        <Link
                                            key={item.href}
                                            href={item.href}
                                            className={cn(
                                                "group flex items-center gap-3 rounded-lg px-3 py-2 text-xs font-semibold transition-all duration-200",
                                                isActive
                                                    ? "bg-zinc-950 text-white dark:bg-zinc-100 dark:text-zinc-900 shadow-md"
                                                    : "text-muted-foreground hover:bg-zinc-100 dark:hover:bg-zinc-800/50 hover:text-foreground"
                                            )}
                                        >
                                            <item.icon
                                                className={cn(
                                                    "h-4 w-4 transition-colors",
                                                    isActive
                                                        ? "text-white dark:text-zinc-900"
                                                        : "text-muted-foreground group-hover:text-foreground"
                                                )}
                                            />
                                            {item.label}
                                        </Link>
                                    );
                                })}
                            </nav>
                        </div>
                    </div>

                    <div className="p-4 mt-auto border-t">
                        <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8 border border-border/10 shadow-sm">
                                <AvatarImage src={user.image || undefined} alt={user.name} />
                                <AvatarFallback className="bg-zinc-950 text-white dark:bg-zinc-100 dark:text-zinc-900 text-[10px] font-bold">
                                    {initials}
                                </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                                <p className="text-xs font-bold truncate leading-none mb-1">{user.name}</p>
                                <p className="text-[10px] text-muted-foreground truncate opacity-70 italic">{user.email}</p>
                            </div>
                            <div className="flex items-center gap-1">
                                <ThemeToggle />
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={handleLogout}
                                    className="h-7 w-7 text-muted-foreground hover:bg-rose-500/10 hover:text-rose-500 transition-colors rounded-lg"
                                >
                                    <LogOut className="h-3.5 w-3.5" />
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </SheetContent>
        </Sheet>
    );
}
