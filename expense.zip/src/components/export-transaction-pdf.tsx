"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Printer } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { format } from "date-fns";

interface ExportTransactionPdfProps {
    transaction: {
        id: string;
        amount: string;
        category: string;
        description: string | null;
        date: Date;
        type: string;
        createdAt: Date;
        image: string | null;
    };
    user: {
        name: string;
        email: string;
        image?: string | null;
    };
}

export function ExportTransactionPdf({ transaction, user }: ExportTransactionPdfProps) {
    const [loading, setLoading] = useState(false);

    const getImageData = (url: string): Promise<string> => {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = "Anonymous";
            img.onload = () => {
                const canvas = document.createElement("canvas");
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext("2d");
                ctx?.drawImage(img, 0, 0);
                resolve(canvas.toDataURL("image/jpeg"));
            };
            img.onerror = reject;
            img.src = url;
        });
    };

    const addFooter = (doc: jsPDF, pageNumber: number, totalPages: number) => {
        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.2);
        doc.line(15, 280, 195, 280);

        doc.setFontSize(7);
        doc.setTextColor(148, 163, 184);
        doc.setFont("helvetica", "normal");
        doc.text("BANK OF USMAN | Standard Financial Statement", 15, 285);
        doc.setFont("helvetica", "bold");
        doc.text("Powered by Usman Zafar", 105, 285, { align: "center" });
        doc.setFont("helvetica", "normal");
        doc.text(`Page ${pageNumber} of ${totalPages}`, 195, 285, { align: "right" });
    };

    const handleExport = async () => {
        setLoading(true);
        try {
            const doc = new jsPDF({
                orientation: "portrait",
                unit: "mm",
                format: "a4",
            });

            const isIncome = transaction.type === "income";
            const primaryColor = isIncome ? [16, 185, 129] : [239, 68, 68];
            const hasImage = !!transaction.image;

            // PAGE 1: TRANSACTION SUMMARY
            // 1. Header
            doc.setFillColor(248, 250, 252);
            doc.rect(0, 0, 210, 45, "F");

            doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
            doc.rect(0, 0, 3, 45, "F");

            doc.setTextColor(30, 41, 59);
            doc.setFontSize(16);
            doc.setFont("helvetica", "bold");
            doc.text("BANK OF USMAN", 15, 18);

            doc.setFontSize(8);
            doc.setFont("helvetica", "normal");
            doc.setTextColor(100, 116, 139);
            doc.text("OFFICIAL TRANSACTION SUMMARY", 15, 24);
            doc.text(`Generated: ${format(new Date(), "PPpp")}`, 15, 28);

            // Statement Type Indicator (Pill)
            doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
            doc.roundedRect(170, 12, 25, 7, 3.5, 3.5, "F");
            doc.setTextColor(255, 255, 255);
            doc.setFontSize(7);
            doc.setFont("helvetica", "bold");
            doc.text(transaction.type.toUpperCase(), 182.5, 16.5, { align: "center" });

            // 2. Info Grid (Remove ID)
            doc.setTextColor(148, 163, 184);
            doc.setFontSize(7);
            doc.setFont("helvetica", "bold");
            doc.text("ISSUED TO", 15, 55);
            doc.text("ACCOUNT EMAIL", 80, 55);
            doc.text("STATEMENT DATE", 145, 55);

            doc.setTextColor(30, 41, 59);
            doc.setFontSize(9);
            doc.setFont("helvetica", "bold");
            doc.text(user.name.toUpperCase(), 15, 61);

            doc.setFontSize(8);
            doc.setFont("helvetica", "normal");
            doc.text(user.email, 80, 61);
            doc.text(format(new Date(), "PPP"), 145, 61);

            // 3. Amount Section (Clean & Minimal)
            doc.setFillColor(252, 253, 254);
            doc.roundedRect(15, 75, 180, 20, 1, 1, "F");

            doc.setTextColor(148, 163, 184);
            doc.setFontSize(6.5);
            doc.setFont("helvetica", "bold");
            doc.text("NET TRANSACTION VALUE", 22, 82);

            doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
            doc.setFontSize(16);
            doc.setFont("helvetica", "bold");
            doc.text(`${isIncome ? "+" : "-"}${formatCurrency(Number(transaction.amount))}`, 22, 89);

            // 4. Enhanced Data Table (Smart & Clean)
            autoTable(doc, {
                startY: 105,
                margin: { left: 15, right: 15 },
                head: [["CLASSIFICATION", "DATE OF TRANSACTION", "CATEGORY", "PAYMENT DESCRIPTION"]],
                body: [[
                    transaction.type.toUpperCase(),
                    formatDate(transaction.date),
                    transaction.category.toUpperCase(),
                    transaction.description || "No description provided."
                ]],
                theme: "plain",
                styles: {
                    fontSize: 7.5,
                    cellPadding: { top: 6, bottom: 6, left: 4, right: 4 },
                    font: "helvetica",
                    textColor: [51, 65, 85],
                },
                headStyles: {
                    fontStyle: "bold",
                    textColor: [148, 163, 184],
                    fontSize: 6.5,
                },
                columnStyles: {
                    0: { cellWidth: 32, fontStyle: "bold", textColor: primaryColor as [number, number, number] },
                    1: { cellWidth: 40 },
                    2: { cellWidth: 35, fontStyle: "bold" },
                    3: { cellWidth: "auto", fontStyle: "normal" }
                },
                didDrawPage: (data) => {
                    // Add a thin line under the header for a "smart" look
                    doc.setDrawColor(241, 245, 249);
                    doc.setLineWidth(0.3);
                    doc.line(15, data.cursor!.y, 195, data.cursor!.y);
                },
                willDrawCell: (data) => {
                    if (data.section === "body") {
                        doc.setDrawColor(248, 250, 252);
                        doc.setLineWidth(0.1);
                        doc.line(data.cell.x, data.cell.y + data.cell.height, data.cell.x + data.cell.width, data.cell.y + data.cell.height);
                    }
                }
            });

            // 5. Minimal Footer Reference
            let nextY = (doc as any).lastAutoTable.finalY + 10;
            doc.setTextColor(203, 213, 225);
            doc.setFontSize(6);
            doc.setFont("helvetica", "normal");
            doc.text(`Digital Timestamp: ${transaction.createdAt.toISOString()}`, 15, nextY);

            addFooter(doc, 1, hasImage ? 2 : 1);

            // PAGE 2: ATTACHMENT
            if (hasImage) {
                doc.addPage();

                doc.setFillColor(248, 250, 252);
                doc.rect(0, 0, 210, 25, "F");

                doc.setTextColor(100, 116, 139);
                doc.setFontSize(8);
                doc.setFont("helvetica", "bold");
                doc.text("ATTACHMENT PROOF", 15, 14);

                doc.setFontSize(7);
                doc.setFont("helvetica", "normal");
                doc.text(`Verification Date: ${format(new Date(), "PPP p")}`, 15, 19);

                try {
                    const imageData = await getImageData(transaction.image!);

                    doc.setDrawColor(241, 245, 249);
                    doc.rect(15, 35, 180, 230);
                    doc.addImage(imageData, "JPEG", 20, 40, 170, 220, undefined, "FAST");

                } catch (e) {
                    doc.setTextColor(239, 68, 68);
                    doc.text("Error: External document proof could not be rendered.", 15, 40);
                }

                addFooter(doc, 2, 2);
            }

            doc.save(`HK-Statement-${format(new Date(), "yyyy-MM-dd")}.pdf`);
            toast.success("Enhanced Statement Exported!");
        } catch (error) {
            console.error("PDF Export error:", error);
            toast.error("Failed to generate statement");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Button
            onClick={handleExport}
            disabled={loading}
            variant="outline"
            className="h-11 px-6 rounded-2xl border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-all font-bold text-xs gap-2 shadow-sm"
        >
            {loading ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
                <Printer className="h-3.5 w-3.5 text-zinc-500" />
            )}
            Export Statement
        </Button>
    );
}
