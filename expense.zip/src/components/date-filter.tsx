"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const filters = [
    { label: "Today", value: "daily" },
    { label: "Week", value: "weekly" },
    { label: "Month", value: "monthly" },
    { label: "Year", value: "yearly" },
    { label: "All", value: "all" },
] as const;

export function DateFilter() {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();
    const currentFilter = searchParams.get("filter") || "all";

    const handleFilter = (value: string) => {
        const params = new URLSearchParams(searchParams.toString());
        params.set("filter", value);
        params.delete("from");
        params.delete("to");
        router.push(`${pathname}?${params.toString()}`);
    };

    return (
        <div className="flex items-center gap-1.5 rounded-2xl bg-zinc-100/80 dark:bg-zinc-900/80 p-1.5 border border-zinc-200/50 dark:border-zinc-800/50 backdrop-blur-sm shadow-sm overflow-x-auto max-w-full no-scrollbar">
            {filters.map((filter) => (
                <Button
                    key={filter.value}
                    variant="ghost"
                    size="sm"
                    onClick={() => handleFilter(filter.value)}
                    className={cn(
                        "h-8 px-4 text-xs font-bold transition-all duration-300 whitespace-nowrap rounded-xl",
                        currentFilter === filter.value
                            ? "bg-white dark:bg-zinc-800 text-violet-600 dark:text-violet-400 shadow-sm scale-105"
                            : "text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-white/50 dark:hover:bg-zinc-800/50"
                    )}
                >
                    {filter.label}
                </Button>
            ))}
        </div>
    );
}
