"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { deleteTransaction } from "@/actions/transaction";
import { TransactionForm } from "@/components/transaction-form";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogClose,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { formatCurrency, formatDate, cn } from "@/lib/utils";
import { Trash2, Paperclip, ChevronLeft, ChevronRight, Eye } from "lucide-react";

interface Transaction {
    id: string;
    type: "income" | "expense";
    amount: string;
    category: string;
    description: string | null;
    date: Date;
    image: string | null;
    createdAt: Date;
}

interface TransactionTableProps {
    transactions: Transaction[];
    type: "income" | "expense" | "all";
    totalCount: number;
    currentPage: number;
}

export function TransactionTable({
    transactions,
    type,
    totalCount,
    currentPage
}: TransactionTableProps) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const totalPages = Math.ceil(totalCount / 10);

    const handlePageChange = (page: number) => {
        const params = new URLSearchParams(searchParams.toString());
        params.set("page", page.toString());
        router.push(`?${params.toString()}`);
    };

    const handleDelete = async (id: string) => {
        try {
            await deleteTransaction(id);
            toast.success("Transaction deleted");
            router.refresh();
        } catch {
            toast.error("Failed to delete");
        }
    };

    if (transactions.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-center animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="h-20 w-20 rounded-3xl bg-violet-500/5 flex items-center justify-center mb-6 ring-1 ring-violet-500/10">
                    <span className="text-3xl">{type === "income" ? "💰" : type === "expense" ? "💸" : "📊"}</span>
                </div>
                <h3 className="text-xl font-semibold tracking-tight">No {type === 'all' ? 'transactions' : type} recorded yet</h3>
                <p className="text-sm text-muted-foreground mt-2 max-w-[250px] mx-auto">
                    Keep your finances organized by adding your first {type === 'all' ? 'transaction' : type}.
                </p>
            </div>
        );
    }

    return (
        <div className="rounded-2xl border bg-card/50 shadow-sm transition-all hover:shadow-md overflow-hidden">
            <div className="overflow-x-auto scrollbar-none">
                <Table>
                    <TableHeader>
                        <TableRow className="bg-muted/30 hover:bg-muted/30 border-b">
                            <TableHead className="py-3 px-4 font-medium text-xs uppercase tracking-wider text-muted-foreground whitespace-nowrap h-10 w-[120px]">Date</TableHead>
                            <TableHead className="py-3 px-4 font-medium text-xs uppercase tracking-wider text-muted-foreground h-10">Category</TableHead>
                            <TableHead className="py-3 px-4 font-medium text-xs uppercase tracking-wider text-muted-foreground h-10 min-w-[150px]">Description</TableHead>
                            <TableHead className="py-3 px-4 font-medium text-xs uppercase tracking-wider text-muted-foreground text-right h-10">Amount</TableHead>
                            <TableHead className="py-3 px-4 font-medium text-xs uppercase tracking-wider text-muted-foreground text-right w-[110px] h-10">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {transactions.map((t) => (
                            <TableRow key={t.id} className="group border-b last:border-0 hover:bg-muted/20 transition-colors duration-200">
                                <TableCell className="py-3 px-4 text-[13px] text-muted-foreground tabular-nums whitespace-nowrap font-medium">
                                    {formatDate(t.date)}
                                </TableCell>
                                <TableCell className="py-3 px-4">
                                    <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-violet-500/10 text-violet-600 ring-1 ring-inset ring-violet-500/20 whitespace-nowrap">
                                        {t.category}
                                    </span>
                                </TableCell>
                                <TableCell className="py-3 px-4">
                                    <div className="flex items-center gap-2 max-w-[280px]">
                                        <span
                                            className="text-[13px] text-foreground/80 truncate font-normal"
                                            title={t.description ?? ""}
                                        >
                                            {t.description || "—"}
                                        </span>

                                        {t.image && (
                                            <a
                                                href={t.image}
                                                target="_blank"
                                                rel="noreferrer"
                                                className="inline-flex shrink-0 items-center justify-center rounded-full bg-blue-500/10 p-1 text-blue-500 hover:bg-blue-500/20 transition-all hover:scale-110"
                                                title="View Attachment"
                                            >
                                                <Paperclip className="h-3 w-3" />
                                            </a>
                                        )}
                                    </div>
                                </TableCell>

                                <TableCell className="py-3 px-4 text-right">
                                    <span className={`text-[14px] font-bold tracking-tight tabular-nums whitespace-nowrap ${t.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                                        {t.type === 'income' ? '+' : '-'}{formatCurrency(Number(t.amount))}
                                    </span>
                                </TableCell>
                                <TableCell className="py-3 px-4 text-right">
                                    <div className="flex items-center justify-end gap-1.5 transition-all duration-200">
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            asChild
                                            className="h-8 w-8 rounded-full text-muted-foreground hover:bg-violet-500/10 hover:text-violet-600 transition-colors"
                                            title="View Details"
                                        >
                                            <Link href={`/transactions/${t.id}`}>
                                                <Eye className="h-3.5 w-3.5" />
                                            </Link>
                                        </Button>
                                        <TransactionForm type={t.type} transaction={t} />
                                        <Dialog>
                                            <DialogTrigger asChild>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8 rounded-full text-muted-foreground hover:bg-rose-500/10 hover:text-rose-500 transition-colors"
                                                >
                                                    <Trash2 className="h-3.5 w-3.5" />
                                                </Button>
                                            </DialogTrigger>
                                            <DialogContent className="max-w-[400px] rounded-2xl border-none shadow-2xl p-0 overflow-hidden bg-card">
                                                <div className="p-6 pb-0 flex flex-col items-center text-center">
                                                    <div className="h-12 w-12 rounded-full bg-rose-500/10 flex items-center justify-center mb-4 ring-8 ring-rose-500/5">
                                                        <Trash2 className="h-6 w-6 text-rose-500" />
                                                    </div>
                                                    <DialogHeader className="space-y-2">
                                                        <DialogTitle className="text-xl font-black tracking-tight">Are you sure?</DialogTitle>
                                                        <DialogDescription className="text-zinc-500 font-medium text-xs leading-relaxed">
                                                            This action cannot be undone. This record will be permanently removed from your history.
                                                        </DialogDescription>
                                                    </DialogHeader>
                                                </div>
                                                <DialogFooter className="flex flex-row gap-2 p-6 pt-8">
                                                    <DialogClose asChild>
                                                        <Button variant="ghost" className="flex-1 rounded-xl font-bold text-[10px] uppercase tracking-wider h-11 hover:bg-zinc-100">
                                                            Cancel
                                                        </Button>
                                                    </DialogClose>
                                                    <Button
                                                        variant="destructive"
                                                        className="flex-1 rounded-xl font-black text-[10px] uppercase tracking-wider h-11 shadow-lg shadow-rose-500/20 bg-rose-500 hover:bg-rose-600 border-none transition-all active:scale-95"
                                                        onClick={() => handleDelete(t.id)}
                                                    >
                                                        Confirm Delete
                                                    </Button>
                                                </DialogFooter>
                                            </DialogContent>
                                        </Dialog>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between px-4 py-3 bg-muted/10 border-t gap-4">
                <div className="text-[13px] text-muted-foreground font-medium">
                    Showing <span className="text-foreground">{Math.min((currentPage - 1) * 10 + 1, totalCount)}</span> to{" "}
                    <span className="text-foreground">{Math.min(currentPage * 10, totalCount)}</span> of{" "}
                    <span className="text-foreground">{totalCount}</span> records
                </div>
                <div className="flex items-center gap-1.5 font-medium">
                    <Button
                        variant="ghost"
                        size="sm"
                        disabled={currentPage === 1}
                        onClick={() => handlePageChange(currentPage - 1)}
                        className="h-8 gap-1 pr-2 hover:bg-violet-500/10 hover:text-violet-600 disabled:opacity-50 transition-all"
                    >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                    </Button>

                    <div className="flex items-center gap-1">
                        {Array.from({ length: totalPages }, (_, i) => i + 1)
                            .filter(p => {
                                return p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1;
                            })
                            .map((p, i, arr) => {
                                const showEllipsis = i > 0 && p - arr[i - 1] > 1;
                                return (
                                    <div key={p} className="flex items-center gap-1">
                                        {showEllipsis && <span className="text-muted-foreground px-1">...</span>}
                                        <Button
                                            variant={currentPage === p ? "secondary" : "ghost"}
                                            size="sm"
                                            onClick={() => handlePageChange(p)}
                                            className={cn(
                                                "h-8 w-8 rounded-lg p-0 transition-all",
                                                currentPage === p
                                                    ? "bg-violet-500 text-white hover:bg-violet-600 shadow-md shadow-violet-500/20"
                                                    : "hover:bg-violet-500/10 hover:text-violet-600"
                                            )}
                                        >
                                            {p}
                                        </Button>
                                    </div>
                                );
                            })}
                    </div>

                    <Button
                        variant="ghost"
                        size="sm"
                        disabled={currentPage === totalPages || totalCount === 0}
                        onClick={() => handlePageChange(currentPage + 1)}
                        className="h-8 gap-1 pl-2 hover:bg-violet-500/10 hover:text-violet-600 disabled:opacity-50 transition-all"
                    >
                        Next
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>
        </div>
    );
}
