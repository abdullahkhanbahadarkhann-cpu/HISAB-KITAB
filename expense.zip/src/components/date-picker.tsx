"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export function DatePicker({ className }: { className?: string }) {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();

    const fromParam = searchParams.get("from");

    // Convert current URL param to YYYY-MM-DD for native date input
    const value = fromParam && !isNaN(new Date(fromParam).getTime())
        ? format(new Date(fromParam), "yyyy-MM-dd")
        : "";

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        const params = new URLSearchParams(searchParams.toString());

        if (val) {
            // Set 'from' to the start of the selected day in ISO format
            params.set("from", new Date(val).toISOString());
            params.delete("to");
            params.delete("filter");
            params.delete("page");
        } else {
            params.delete("from");
            params.delete("to");
        }

        router.push(`${pathname}?${params.toString()}`);
    };

    return (
        <Input
            type="date"
            value={value}
            onChange={handleChange}
            className={cn("h-11 sm:w-[200px]", className)}
        />
    );
}
