"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { signUp } from "@/lib/auth-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Wallet, ArrowRight } from "lucide-react";

export default function RegisterPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    // useEffect(() => {
    //     router.push("/login");
    // }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (password.length < 8) {
            toast.error("Password must be at least 8 characters");
            return;
        }

        setLoading(true);

        try {
            const result = await signUp.email({
                name,
                email,
                password,
            });

            if (result.error) {
                toast.error(result.error.message || "Registration failed");
                setLoading(false);
                return;
            }

            toast.success("Account created successfully!");
            router.push("/dashboard");
            router.refresh();
        } catch {
            toast.error("Something went wrong");
            setLoading(false);
        }
    };

    return (
        <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
            <div className="hidden bg-muted lg:block relative overflow-hidden">
                <div className="absolute inset-0 bg-zinc-950/20 z-10" />
                <Image
                    src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop"
                    alt="Register background"
                    width="1920"
                    height="1080"
                    className="h-full w-full object-cover dark:brightness-[0.4] dark:grayscale"
                />
                <div className="absolute top-12 left-12 z-20 max-w-md">
                    <p className="text-white text-3xl font-black tracking-tighter leading-tight drop-shadow-2xl">
                        Join the Elite. <br /> Master Your Money.
                    </p>
                    <div className="mt-4 h-1 w-12 bg-white rounded-full transition-all duration-500" />
                </div>
            </div>
            <div className="flex items-center justify-center py-12 px-6 lg:px-8">
                <div className="mx-auto grid w-full max-w-[350px] gap-8">
                    <div className="grid gap-2 text-center lg:text-left">
                        <div className="flex items-center gap-2 justify-center lg:justify-start mb-4">
                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-zinc-950 dark:bg-zinc-50 shadow-sm transition-transform hover:rotate-3">
                                <Wallet className="h-4 w-4 text-white dark:text-zinc-950" />
                            </div>
                            <div>
                                <h1 className="text-sm font-black tracking-tight leading-none">HISAB KITAB</h1>
                                <p className="text-[10px] text-muted-foreground font-bold tracking-[0.1em] mt-1 uppercase opacity-60">PRO EDITION</p>
                            </div>
                        </div>
                        <h1 className="text-2xl font-black tracking-tight">Create account</h1>
                        <p className="text-balance text-sm text-muted-foreground font-medium">
                            Enter your details below to create your pro account
                        </p>
                    </div>
                    <form onSubmit={handleSubmit} className="grid gap-4">
                        <div className="grid gap-2">
                            <Label htmlFor="name" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Full Name</Label>
                            <Input
                                id="name"
                                type="text"
                                placeholder="John Doe"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                                className="h-10 text-xs rounded-lg border-border/60 bg-muted/20"
                            />
                        </div>
                        <div className="grid gap-2">
                            <Label htmlFor="email" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Email</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="m@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                className="h-10 text-xs rounded-lg border-border/60 bg-muted/20"
                            />
                        </div>
                        <div className="grid gap-2">
                            <Label htmlFor="password" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Password</Label>
                            <Input
                                id="password"
                                type="password"
                                required
                                placeholder="Min 8 characters"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="h-10 text-xs rounded-lg border-border/60 bg-muted/20"
                            />
                        </div>
                        <Button
                            type="submit"
                            className="w-full bg-zinc-950 dark:bg-zinc-50 text-white dark:text-zinc-900 rounded-lg h-10 text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 shadow-lg shadow-zinc-500/10 mt-2"
                            disabled={loading}
                        >
                            {loading ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                                <span className="flex items-center gap-2">
                                    Create Account <ArrowRight className="h-3 w-3" />
                                </span>
                            )}
                        </Button>
                    </form>
                    <div className="mt-4 text-center text-sm">
                        Already have an account?{" "}
                        <Link href="/login" className="font-bold underline underline-offset-4">
                            Sign in
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
