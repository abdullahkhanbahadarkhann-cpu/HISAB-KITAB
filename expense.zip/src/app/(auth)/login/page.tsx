"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { signIn } from "@/lib/auth-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Wallet, Mail, Lock, ArrowRight } from "lucide-react";

export default function LoginPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const result = await signIn.email({
                email,
                password,
            });

            if (result.error) {
                toast.error(result.error.message || "Invalid credentials");
                setLoading(false);
                return;
            }

            toast.success("Welcome back!");
            router.push("/dashboard");
            router.refresh();
        } catch {
            toast.error("Something went wrong");
            setLoading(false);
        }
    };

    return (
        <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
            <div className="flex items-center justify-center py-12 px-6 lg:px-8">
                <div className="mx-auto grid w-full max-w-[350px] gap-8">
                    <div className="grid gap-2 text-center lg:text-left">
                        <div className="flex items-center gap-2 justify-center lg:justify-start mb-4">
                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-zinc-950 dark:bg-zinc-50 shadow-sm transition-transform hover:rotate-3">
                                <Wallet className="h-4 w-4 text-white dark:text-zinc-950" />
                            </div>
                            <div>
                                <h1 className="text-sm font-black tracking-tight leading-none">HISAB KITAB</h1>
                                <p className="text-[10px] text-muted-foreground font-bold tracking-[0.1em] mt-1 uppercase opacity-60">PRO EDITION</p>
                            </div>
                        </div>
                        <h1 className="text-2xl font-black tracking-tight">Login</h1>
                        <p className="text-balance text-sm text-muted-foreground font-medium">
                            Enter your email below to login to your account
                        </p>
                    </div>
                    <form onSubmit={handleSubmit} className="grid gap-4">
                        <div className="grid gap-2">
                            <Label htmlFor="email" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Email</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="m@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                className="h-10 text-xs rounded-lg border-border/60 bg-muted/20"
                            />
                        </div>
                        <div className="grid gap-2">
                            <div className="flex items-center">
                                <Label htmlFor="password" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Password</Label>
                                <Link
                                    href="/forgot-password"
                                    className="ml-auto inline-block text-[10px] font-bold uppercase tracking-wider underline underline-offset-4"
                                >
                                    Forgot your password?
                                </Link>
                            </div>
                            <Input
                                id="password"
                                type="password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="h-10 text-xs rounded-lg border-border/60 bg-muted/20"
                            />
                        </div>
                        <Button
                            type="submit"
                            className="w-full bg-zinc-950 dark:bg-zinc-50 text-white dark:text-zinc-900 rounded-lg h-10 text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 shadow-lg shadow-zinc-500/10 mt-2"
                            disabled={loading}
                        >
                            {loading ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                                <span className="flex items-center gap-2">
                                    Login <ArrowRight className="h-3 w-3" />
                                </span>
                            )}
                        </Button>
                        <Button variant="outline" className="w-full rounded-lg h-10 text-[10px] font-black uppercase tracking-wider border-zinc-200 dark:border-zinc-800">
                            Login with Google
                        </Button>
                    </form>
                    <div className="mt-4 text-center text-sm">
                        Don&apos;t have an account?{" "}
                        <Link href="/register" className="font-bold underline underline-offset-4">
                            Sign up
                        </Link>
                    </div>
                </div>
            </div>
            <div className="hidden bg-muted lg:block relative overflow-hidden">
                <div className="absolute inset-0 bg-zinc-950/20 z-10" />
                <Image
                    src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop"
                    alt="Image"
                    width="1920"
                    height="1080"
                    className="h-full w-full object-cover dark:brightness-[0.4] dark:grayscale"
                />
                <div className="absolute bottom-12 left-12 z-20 max-w-md">
                    <p className="text-white text-3xl font-black tracking-tighter leading-tight drop-shadow-2xl">
                        Elite Financial Control at Your Fingertips.
                    </p>
                    <div className="mt-4 h-1 w-12 bg-white rounded-full transition-all duration-500" />
                </div>
            </div>
        </div>
    );
}
