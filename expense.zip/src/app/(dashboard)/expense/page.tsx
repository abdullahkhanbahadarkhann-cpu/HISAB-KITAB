import { Suspense } from "react";
import { headers } from "next/headers";
import { auth } from "@/lib/auth";
import { getTransactions, type DateFilter } from "@/queries/transactions";
import { TransactionForm } from "@/components/transaction-form";
import { ExportPdfButton } from "@/components/export-pdf-button";
import { TransactionTable } from "@/components/transaction-table";
import { DateFilter as DateFilterComponent } from "@/components/date-filter";
import { CategoryFilter } from "@/components/category-filter";
import { SearchInput } from "@/components/search-input";
import { Card, CardContent } from "@/components/ui/card";
import { DatePicker } from "@/components/date-picker";
import { ResetFilters } from "@/components/reset-filters";
import { formatCurrency } from "@/lib/utils";
import { TrendingDown } from "lucide-react";

interface ExpensePageProps {
    searchParams: Promise<{
        filter?: string;
        category?: string;
        search?: string;
        from?: string;
        to?: string;
        page?: string;
    }>;
}

export default async function ExpensePage({ searchParams }: ExpensePageProps) {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) return null;

    const params = await searchParams;
    const filter = (params.filter || "all") as DateFilter;
    const category = params.category;
    const search = params.search;
    const startDate = params.from ? new Date(params.from) : undefined;
    const endDate = params.to ? new Date(params.to) : undefined;
    const page = Number(params.page) || 1;
    const pageSize = 10;

    const { transactions, totalCount, totalAmount } = await getTransactions(
        session.user.id,
        "expense",
        filter,
        category,
        search,
        startDate,
        endDate,
        page,
        pageSize
    );

    return (
        <div className="space-y-8 pb-8 w-full mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-0.5">
                    <h1 className="text-xl font-black tracking-tight">Expense</h1>
                    <p className="text-muted-foreground font-medium text-xs flex items-center gap-2">
                        <span className="h-1 w-1 rounded-full bg-rose-500" />
                        Manage your outgoing costs
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <ExportPdfButton
                        type="expense"
                        filter={filter}
                        category={category}
                        search={search}
                        startDate={params.from}
                        endDate={params.to}
                        user={session.user}
                    />
                    <TransactionForm type="expense" />
                </div>
            </div>

            <Card className="border border-border shadow-none bg-card rounded-xl overflow-hidden max-w-sm">
                <CardContent className="flex items-center gap-4 p-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/5 text-rose-600 border border-rose-500/10">
                        <TrendingDown className="h-5 w-5" />
                    </div>
                    <div>
                        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest leading-none mb-1">Total Expense</p>
                        <p className="text-xl font-black text-rose-600 leading-none">
                            {formatCurrency(totalAmount)}
                        </p>
                    </div>
                </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex flex-col xl:flex-row items-start xl:items-center gap-3 w-full">
                    <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 w-full sm:w-auto">
                        <Suspense>
                            <DateFilterComponent />
                        </Suspense>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                            <DatePicker className="flex-1 sm:w-48 sm:flex-none" />
                            <Suspense>
                                <CategoryFilter type="expense" />
                            </Suspense>
                        </div>
                        <Suspense>
                            <ResetFilters />
                        </Suspense>
                    </div>
                </div>
                <Suspense>
                    <SearchInput placeholder="Filter expense..." />
                </Suspense>
            </div>

            <TransactionTable
                transactions={transactions}
                type="expense"
                totalCount={totalCount}
                currentPage={page}
            />
        </div>
    );
}
