import { headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { getTransactionById } from "@/queries/transactions";
import { formatCurrency, formatDate, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Calendar,
    Tag,
    FileText,
    Receipt,
    ExternalLink,
    TrendingUp,
    TrendingDown,
    ArrowLeft
} from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { Separator } from "@/components/ui/separator";
import { ExportTransactionPdf } from "@/components/export-transaction-pdf";

interface TransactionPageProps {
    params: Promise<{ id: string }>;
}

export default async function TransactionPage({ params }: TransactionPageProps) {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) {
        redirect("/login");
    }

    const { id } = await params;
    const transaction = await getTransactionById(id, session.user.id);

    if (!transaction) {
        notFound();
    }

    const isIncome = transaction.type === "income";

    return (
        <div className="w-full mx-auto space-y-4 sm:space-y-6 px-0 sm:px-4">
            <div className="flex items-center justify-between px-4 sm:px-0">
                <Button variant="ghost" size="sm" asChild className="-ml-2 sm:-ml-3 gap-2 text-muted-foreground hover:text-foreground">
                    <Link href={isIncome ? "/income" : "/expense"}>
                        <ArrowLeft className="h-4 w-4" />
                        <span className="text-xs sm:text-sm font-medium">Back to {isIncome ? "Income" : "Expense"}</span>
                    </Link>
                </Button>
                <ExportTransactionPdf transaction={transaction} user={session.user} />
            </div>

            <div className="overflow-hidden rounded-2xl sm:rounded-3xl border bg-card/50 shadow-xl backdrop-blur-sm mx-2 sm:mx-0">
                {/* Header Section */}
                <div className={cn(
                    "p-5 sm:p-8 text-white transition-all",
                    isIncome
                        ? "bg-gradient-to-br from-emerald-500 to-teal-600"
                        : "bg-gradient-to-br from-rose-500 to-red-600"
                )}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-6">
                        <div className="space-y-2">
                            <div className="flex items-center gap-2.5">
                                <div className="p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-white/20 backdrop-blur-md">
                                    {isIncome ? <TrendingUp className="h-5 w-5 sm:h-6 sm:h-6" /> : <TrendingDown className="h-5 w-5 sm:h-6 sm:h-6" />}
                                </div>
                                <Badge className="bg-white/20 border-none text-[10px] sm:text-xs text-white hover:bg-white/30 capitalize px-2 py-0">
                                    {transaction.type}
                                </Badge>
                            </div>
                            <h1 className="text-xl sm:text-3xl font-bold tracking-tight">Transaction Details</h1>
                            <p className="text-white/80 text-[10px] sm:text-sm font-medium opacity-80 truncate max-w-[200px] sm:max-w-none">Ref: {transaction.id}</p>
                        </div>
                        <div className="sm:text-right">
                            <p className="text-white/70 text-[10px] sm:text-sm font-medium uppercase tracking-widest mb-0.5 sm:mb-1">Amount</p>
                            <p className="text-3xl sm:text-5xl font-black tracking-tighter">
                                {isIncome ? "+" : "-"}{formatCurrency(Number(transaction.amount))}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Content Section */}
                <div className="p-5 sm:p-8 space-y-6 sm:space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
                        <div className="space-y-5 sm:space-y-6">
                            <div className="grid grid-cols-2 gap-3 sm:gap-4">
                                <div className="space-y-1.5">
                                    <label className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-2">
                                        <Tag className="h-3 sm:h-3.5 w-3 sm:w-3.5" /> Category
                                    </label>
                                    <div className="text-sm sm:text-base font-semibold bg-muted/40 px-3 sm:px-4 py-2 sm:py-3 rounded-xl sm:rounded-2xl border border-muted-foreground/10">
                                        {transaction.category}
                                    </div>
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-2">
                                        <Calendar className="h-3 sm:h-3.5 w-3 sm:w-3.5" /> Date
                                    </label>
                                    <div className="text-sm sm:text-base font-semibold bg-muted/40 px-3 sm:px-4 py-2 sm:py-3 rounded-xl sm:rounded-2xl border border-muted-foreground/10">
                                        {formatDate(transaction.date)}
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <label className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-2">
                                    <FileText className="h-3 sm:h-3.5 w-3 sm:w-3.5" /> Description
                                </label>
                                <div className="text-xs sm:text-sm text-foreground/90 bg-muted/20 px-4 sm:px-5 py-3 sm:py-4 rounded-xl sm:rounded-2xl border border-muted-foreground/10 leading-relaxed min-h-[100px] sm:min-h-[120px]">
                                    {transaction.description || "No description provided."}
                                </div>
                            </div>
                        </div>

                        {/* Attachment Section */}
                        <div className="space-y-3 sm:space-y-4">
                            <label className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-2">
                                <Receipt className="h-3 sm:h-3.5 w-3 sm:w-3.5" /> Receipt / Attachment
                            </label>
                            {transaction.image ? (
                                <div className="relative group overflow-hidden rounded-2xl sm:rounded-3xl border-2 border-muted shadow-lg bg-muted/30">
                                    <div className="aspect-[4/3] relative overflow-hidden">
                                        <Image
                                            src={transaction.image}
                                            alt="Receipt"
                                            fill
                                            className="object-contain transition-transform duration-700 group-hover:scale-110"
                                        />
                                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-3">
                                            <a
                                                href={transaction.image}
                                                target="_blank"
                                                rel="noreferrer"
                                                className="bg-white text-black px-4 sm:px-6 py-2 sm:py-2.5 rounded-full text-[10px] sm:text-sm font-bold flex items-center gap-2 shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
                                            >
                                                <ExternalLink className="h-3 sm:h-4 w-3 sm:w-4" />
                                                View Full Size
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="aspect-[4/3] rounded-2xl sm:rounded-3xl border-2 border-dashed flex flex-col items-center justify-center text-muted-foreground bg-muted/5 group hover:bg-muted/10 transition-colors">
                                    <Receipt className="h-10 sm:h-12 w-10 sm:w-12 mb-2 sm:mb-3 opacity-20 group-hover:scale-110 transition-transform" />
                                    <span className="text-xs sm:text-sm font-medium italic opacity-50">No attachment available</span>
                                </div>
                            )}
                        </div>
                    </div>

                    <Separator className="opacity-50" />

                    <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between text-[10px] sm:text-xs text-muted-foreground font-medium italic">
                        <p>Recorded on {formatDate(transaction.createdAt)}</p>
                        <p className="truncate opacity-50">ID: {transaction.id}</p>
                    </div>
                </div>
            </div>
        </div>
    );
}
