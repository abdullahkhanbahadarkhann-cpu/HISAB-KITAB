import { headers } from "next/headers";
import { auth } from "@/lib/auth";
import { SettingsForm } from "@/components/settings-form";

export default async function SettingsPage() {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) return null;

    return (
        <div className="space-y-8 pb-8 w-full mx-auto">
            <div className="space-y-0.5">
                <h1 className="text-xl font-black tracking-tight">Settings</h1>
                <p className="text-muted-foreground font-medium text-xs flex items-center gap-2">
                    <span className="h-1 w-1 rounded-full bg-zinc-400" />
                    Manage your account and security preferences
                </p>
            </div>

            <SettingsForm
                user={{
                    id: session.user.id,
                    name: session.user.name,
                    email: session.user.email,
                    image: session.user.image,
                }}
            />
        </div>
    );
}
