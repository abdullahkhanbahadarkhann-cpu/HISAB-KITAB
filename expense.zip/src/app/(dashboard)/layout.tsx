import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { Sidebar } from "@/components/sidebar";
import { MobileSidebar } from "@/components/mobile-sidebar";

export default async function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) {
        redirect("/login");
    }

    return (
        <div className="flex h-screen overflow-hidden bg-muted/30">
            <div className="hidden md:flex">
                <Sidebar
                    user={{
                        name: session.user.name,
                        email: session.user.email,
                        image: session.user.image,
                    }}
                />
            </div>
            <main className="flex-1 overflow-y-auto">
                <div className="sticky top-0 z-10 flex items-center gap-4 border-b bg-background/80 backdrop-blur-sm px-6 py-3 md:hidden">
                    <MobileSidebar
                        user={{
                            name: session.user.name,
                            email: session.user.email,
                            image: session.user.image,
                        }}
                    />
                    <h1 className="text-lg font-bold">Hisab Kitab</h1>
                </div>
                <div className="p-6 lg:p-8">{children}</div>
            </main>
        </div>
    );
}
