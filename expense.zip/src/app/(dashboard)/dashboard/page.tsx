import { headers } from "next/headers";
import { auth } from "@/lib/auth";
import {
    getTransactionSummary,
    getMonthlyChart,
    getRecentTransactions,
    getCategoryData
} from "@/queries/transactions";
import { SummaryCard } from "@/components/summary-card";
import { OverviewChart, CategoryPieChart } from "@/components/charts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/utils";
import {
    TrendingUp,
    TrendingDown,
    ArrowRight,
    Plus,
    Calendar,
    Wallet
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default async function DashboardPage() {
    const session = await auth.api.getSession({
        headers: await headers(),
    });

    if (!session) return null;

    const [summaries, chartData, recentTransactions, categoryData] = await Promise.all([
        getTransactionSummary(session.user.id),
        getMonthlyChart(session.user.id),
        getRecentTransactions(session.user.id, 6),
        getCategoryData(session.user.id, "expense"),
    ]);

    return (
        <div className="space-y-8 pb-8  w-full mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-0.5">
                    <h1 className="text-xl font-black tracking-tight text-foreground">Overview</h1>
                    <p className="text-muted-foreground font-medium text-xs flex items-center gap-2">
                        <span className="h-1 w-1 rounded-full bg-emerald-500" />
                        Welcome back, {session.user.name.split(" ")[0]}
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <Button asChild variant="outline" size="sm" className="hidden sm:flex rounded-lg h-8 text-[10px] font-bold uppercase tracking-wider">
                        <Link href="/transactions" className="flex items-center gap-2">
                            <Calendar className="h-3 w-3" /> History
                        </Link>
                    </Button>
                    <Button asChild size="sm" className="bg-zinc-950 dark:bg-zinc-50 text-zinc-50 dark:text-zinc-950 hover:opacity-90 rounded-lg h-8 px-4 text-[10px] font-bold uppercase tracking-wider transition-all active:scale-95">
                        <Link href="/income" className="flex items-center gap-2">
                            <Plus className="h-3 w-3" /> New Record
                        </Link>
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                {summaries.map((summary, index) => (
                    <SummaryCard
                        key={summary.label}
                        label={summary.label}
                        income={summary.income}
                        expense={summary.expense}
                        balance={summary.balance}
                        isActive={index === 4}
                    />
                ))}
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                <div className="xl:col-span-2">
                    <OverviewChart data={chartData} />
                </div>
                <div>
                    <CategoryPieChart data={categoryData} />
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="border border-border shadow-none lg:col-span-2 rounded-xl overflow-hidden bg-card">
                    <CardHeader className="flex flex-row items-center justify-between p-6 pb-2">
                        <div className="space-y-0.5">
                            <CardTitle className="text-base font-bold tracking-tight">
                                Recent Activity
                            </CardTitle>
                            <CardDescription className="text-[10px] uppercase font-bold tracking-wider opacity-60">Latest transaction flow</CardDescription>
                        </div>
                        <Button variant="ghost" size="sm" asChild className="rounded-lg h-7 text-[10px] font-bold uppercase tracking-wider hover:bg-muted opacity-70">
                            <Link href="/transactions" className="flex items-center gap-1.5">
                                Full History <ArrowRight className="h-3 w-3" />
                            </Link>
                        </Button>
                    </CardHeader>
                    <CardContent className="px-3 pb-6">
                        <div className="space-y-0.5">
                            {recentTransactions.length === 0 ? (
                                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
                                    <div className="p-3 rounded-xl bg-muted/30">
                                        <Wallet className="h-6 w-6 opacity-30" />
                                    </div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest opacity-40">No records found</p>
                                </div>
                            ) : (
                                recentTransactions.map((t) => (
                                    <Link
                                        key={t.id}
                                        href={`/transactions/${t.id}`}
                                        className="group/item flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-all duration-200 border border-transparent hover:border-border/50"
                                    >
                                        <div className="flex items-center gap-3">
                                            <div
                                                className={`flex h-9 w-9 items-center justify-center rounded-lg border transition-all ${t.type === "income"
                                                    ? "bg-emerald-500/5 text-emerald-600 border-emerald-500/10"
                                                    : "bg-rose-500/5 text-rose-600 border-rose-500/10"
                                                    }`}
                                            >
                                                {t.type === "income" ? (
                                                    <TrendingUp className="h-4 w-4" />
                                                ) : (
                                                    <TrendingDown className="h-4 w-4" />
                                                )}
                                            </div>
                                            <div>
                                                <p className="text-xs font-bold text-foreground/90">{t.category}</p>
                                                <p className="text-[10px] text-muted-foreground font-medium flex items-center gap-1 mt-0.5 opacity-60">
                                                    {formatDate(t.date)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="text-right flex flex-col items-end gap-1">
                                            <p className={`text-xs font-black tracking-tight ${t.type === "income"
                                                ? "text-emerald-600"
                                                : "text-rose-600"
                                                }`}>
                                                {t.type === "income" ? "+" : "-"}{formatCurrency(Number(t.amount))}
                                            </p>
                                            <Badge variant="outline" className="text-[8px] uppercase tracking-[0.1em] h-3.5 px-1.5 rounded-sm border-border/50 text-muted-foreground/60 font-black">
                                                {t.type}
                                            </Badge>
                                        </div>
                                    </Link>
                                ))
                            )}
                        </div>
                    </CardContent>
                </Card>

                <div className="space-y-6">
                    <Card className="border border-zinc-800 bg-zinc-950 text-white rounded-xl p-3 overflow-hidden relative group">
                        <div className="absolute -top-6 -right-6 p-4 opacity-5 group-hover:rotate-6 transition-transform duration-700">
                            <Wallet className="h-32 w-32" />
                        </div>
                        <CardHeader className="relative z-10 pb-1">
                            <CardTitle className="text-[10px] font-black text-zinc-500 tracking-[0.2em] uppercase">Quick Statistics</CardTitle>
                        </CardHeader>
                        <CardContent className="relative z-10 space-y-4">
                            <div className="space-y-1">
                                <p className="text-[8px] uppercase font-bold text-zinc-600 tracking-widest">Primary category</p>
                                <p className="text-lg font-black">{categoryData[0]?.name || "N/A"}</p>
                                <div className="h-1 w-full bg-zinc-900 rounded-full mt-2 overflow-hidden">
                                    <div className="h-full bg-white w-[65%]" />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 pt-1">
                                <div className="space-y-0.5">
                                    <p className="text-[8px] uppercase font-bold text-zinc-600 tracking-widest">Momentum</p>
                                    <p className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                                        +12% <TrendingUp className="h-2.5 w-2.5" />
                                    </p>
                                </div>
                                <div className="space-y-0.5">
                                    <p className="text-[8px] uppercase font-bold text-zinc-600 tracking-widest">Health</p>
                                    <p className="text-xs font-bold text-zinc-400">Stable</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <div className="grid grid-cols-2 gap-3">
                        <Button asChild variant="outline" className="h-auto py-5 flex-col gap-2 rounded-xl bg-card border-border hover:bg-muted/50 transition-all active:scale-95">
                            <Link href="/income" className="w-full h-full flex flex-col items-center">
                                <div className="p-2.5 rounded-lg bg-emerald-500/5 text-emerald-600 border border-emerald-500/10">
                                    <TrendingUp className="h-4 w-4" />
                                </div>
                                <span className="text-[10px] font-black uppercase tracking-wider mt-2">Income</span>
                            </Link>
                        </Button>
                        <Button asChild variant="outline" className="h-auto py-5 flex-col gap-2 rounded-xl bg-card border-border hover:bg-muted/50 transition-all active:scale-95">
                            <Link href="/expense" className="w-full h-full flex flex-col items-center">
                                <div className="p-2.5 rounded-lg bg-rose-500/5 text-rose-600 border border-rose-500/10">
                                    <TrendingDown className="h-4 w-4" />
                                </div>
                                <span className="text-[10px] font-black uppercase tracking-wider mt-2">Expense</span>
                            </Link>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
