import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "sonner";
import { ThemeProvider } from "@/components/theme-provider";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
    title: "Hisab Kitab - Expense Tracker",
    description: "Track your income and expenses with ease. A modern, production-ready expense tracker.",
    applicationName: "Hisab Kitab",
    manifest: "/manifest.webmanifest",
    themeColor: "#0f172a",
    appleWebApp: {
        capable: true,
        statusBarStyle: "default",
        title: "Hisab Kitab",
    },
    icons: {
        icon: [
            { url: "/favicon.svg", type: "image/svg+xml" },
            { url: "/icons/icon-192.svg", sizes: "192x192", type: "image/svg+xml" },
            { url: "/icons/icon-512.svg", sizes: "512x512", type: "image/svg+xml" },
        ],
        apple: [{ url: "/icons/icon-192.svg", sizes: "192x192", type: "image/svg+xml" }],
    },
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en" suppressHydrationWarning>
            <body className={inter.className}>
                <ThemeProvider
                    attribute="class"
                    defaultTheme="system"
                    enableSystem
                    disableTransitionOnChange
                >
                    {children}
                    <Toaster position="top-right" richColors closeButton />
                </ThemeProvider>
            </body>
        </html>
    );
}
