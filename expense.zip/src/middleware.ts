import { NextRequest, NextResponse } from "next/server";

export async function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl;

    // Better Auth handles session cookies. In production (HTTPS), 
    // it prefixes them with __Secure-
    const sessionCookie =
        request.cookies.get("better-auth.session_token") ||
        request.cookies.get("__Secure-better-auth.session_token");

    const isAuthenticated = !!sessionCookie;

    const authRoutes = ["/login", "/register"];
    const isAuthRoute = authRoutes.some((route) => pathname.startsWith(route));

    // 1. Handle Root Route "/"
    if (pathname === "/") {
        return NextResponse.redirect(new URL(isAuthenticated ? "/dashboard" : "/login", request.url));
    }

    // 2. Prevent logged-in users from accessing auth routes
    if (isAuthenticated && isAuthRoute) {
        return NextResponse.redirect(new URL("/dashboard", request.url));
    }

    // 3. Protect all other routes (except auth and root which are handled above)
    if (!isAuthenticated && !isAuthRoute) {
        return NextResponse.redirect(new URL("/login", request.url));
    }

    return NextResponse.next();
}

export const config = {
    matcher: ["/((?!api|_next/static|_next/image|favicon.ico|manifest.webmanifest|sw.js|workbox-.*|icons/).*)"],
};
