import { db } from "@/db";
import { transaction } from "@/db/schema";
import { eq, and, sql, desc, gte, lte, ilike } from "drizzle-orm";
import {
    startOfDay,
    endOfDay,
    startOfWeek,
    endOfWeek,
    startOfMonth,
    endOfMonth,
    startOfYear,
    endOfYear,
} from "date-fns";

export type TransactionType = "income" | "expense";

export type DateFilter = "daily" | "weekly" | "monthly" | "yearly" | "all";

function getDateRange(filter: DateFilter): { start: Date; end: Date } | null {
    const now = new Date();

    switch (filter) {
        case "daily":
            return { start: startOfDay(now), end: endOfDay(now) };
        case "weekly":
            return { start: startOfWeek(now, { weekStartsOn: 1 }), end: endOfWeek(now, { weekStartsOn: 1 }) };
        case "monthly":
            return { start: startOfMonth(now), end: endOfMonth(now) };
        case "yearly":
            return { start: startOfYear(now), end: endOfYear(now) };
        case "all":
            return null;
    }
}

export async function getTransactions(
    userId: string,
    type: TransactionType | "all",
    filter: DateFilter = "all",
    category?: string,
    search?: string,
    startDate?: Date,
    endDate?: Date,
    page: number = 1,
    pageSize: number = 10
) {
    let dateRange = getDateRange(filter);

    if (startDate) {
        const end = endDate || startDate;
        dateRange = { start: startOfDay(startDate), end: endOfDay(end) };
    }

    const conditions = [
        eq(transaction.userId, userId),
    ];

    if (type !== "all") {
        conditions.push(eq(transaction.type, type));
    }

    if (dateRange) {
        conditions.push(gte(transaction.date, dateRange.start));
        conditions.push(lte(transaction.date, dateRange.end));
    }

    if (category && category.toLowerCase() !== "all") {
        conditions.push(eq(transaction.category, category));
    }

    if (search && search.trim() !== "") {
        conditions.push(ilike(transaction.description, `%${search}%`));
    }

    const [data, countResult, sumResult] = await Promise.all([
        db
            .select()
            .from(transaction)
            .where(and(...conditions))
            .orderBy(desc(transaction.date))
            .limit(pageSize)
            .offset((page - 1) * pageSize),
        db
            .select({ count: sql<number>`count(*)` })
            .from(transaction)
            .where(and(...conditions)),
        db
            .select({
                totalIncome: sql<string>`COALESCE(SUM(CASE WHEN ${transaction.type} = 'income' THEN ${transaction.amount} ELSE 0 END), 0)`,
                totalExpense: sql<string>`COALESCE(SUM(CASE WHEN ${transaction.type} = 'expense' THEN ${transaction.amount} ELSE 0 END), 0)`
            })
            .from(transaction)
            .where(and(...conditions)),
    ]);

    return {
        transactions: data,
        totalCount: Number(countResult[0]?.count || 0),
        totalIncome: Number(sumResult[0]?.totalIncome || 0),
        totalExpense: Number(sumResult[0]?.totalExpense || 0),
        totalAmount: Number(sumResult[0]?.totalIncome || 0) - Number(sumResult[0]?.totalExpense || 0),
    };
}

export async function getTransactionSummary(userId: string) {
    const periods: { label: string; filter: DateFilter }[] = [
        { label: "Today", filter: "daily" },
        { label: "This Week", filter: "weekly" },
        { label: "This Month", filter: "monthly" },
        { label: "This Year", filter: "yearly" },
        { label: "All Time", filter: "all" },
    ];

    const summaries = await Promise.all(
        periods.map(async (period) => {
            const dateRange = getDateRange(period.filter);

            const conditions = [eq(transaction.userId, userId)];

            if (dateRange) {
                conditions.push(gte(transaction.date, dateRange.start));
                conditions.push(lte(transaction.date, dateRange.end));
            }

            const result = await db
                .select({
                    type: transaction.type,
                    total: sql<string>`COALESCE(SUM(${transaction.amount}), 0)`,
                })
                .from(transaction)
                .where(and(...conditions))
                .groupBy(transaction.type);

            const income = Number(result.find((r) => r.type === "income")?.total || 0);
            const expense = Number(result.find((r) => r.type === "expense")?.total || 0);

            return {
                label: period.label,
                filter: period.filter,
                income,
                expense,
                balance: income - expense,
            };
        })
    );

    return summaries;
}

export async function getMonthlyChart(userId: string) {
    const now = new Date();
    const startDate = startOfYear(now);
    const endDate = endOfYear(now);

    const result = await db
        .select({
            month: sql<number>`EXTRACT(MONTH FROM ${transaction.date})`,
            type: transaction.type,
            total: sql<string>`COALESCE(SUM(${transaction.amount}), 0)`,
        })
        .from(transaction)
        .where(
            and(
                eq(transaction.userId, userId),
                gte(transaction.date, startDate),
                lte(transaction.date, endDate)
            )
        )
        .groupBy(sql`EXTRACT(MONTH FROM ${transaction.date})`, transaction.type)
        .orderBy(sql`EXTRACT(MONTH FROM ${transaction.date})`);

    const months = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    ];

    return months.map((name, index) => {
        const monthData = result.filter((r) => Number(r.month) === index + 1);
        return {
            name,
            income: Number(monthData.find((d) => d.type === "income")?.total || 0),
            expense: Number(monthData.find((d) => d.type === "expense")?.total || 0),
        };
    });
}

export async function getRecentTransactions(userId: string, limit = 5) {
    return db
        .select()
        .from(transaction)
        .where(eq(transaction.userId, userId))
        .orderBy(desc(transaction.date))
        .limit(limit);
}

export async function getTransactionById(id: string, userId: string) {
    const result = await db
        .select()
        .from(transaction)
        .where(and(eq(transaction.id, id), eq(transaction.userId, userId)))
        .limit(1);

    return result[0];
}

export async function getTransactionsForExport(
    userId: string,
    type: TransactionType | "all",
    filter: DateFilter = "all",
    category?: string,
    search?: string,
    startDate?: Date,
    endDate?: Date
) {
    let dateRange = getDateRange(filter);

    if (startDate && endDate) {
        dateRange = { start: startOfDay(startDate), end: endOfDay(endDate) };
    }

    const conditions = [
        eq(transaction.userId, userId),
    ];

    if (type !== "all") {
        conditions.push(eq(transaction.type, type));
    }

    if (dateRange) {
        conditions.push(gte(transaction.date, dateRange.start));
        conditions.push(lte(transaction.date, dateRange.end));
    }

    if (category && category.toLowerCase() !== "all") {
        conditions.push(eq(transaction.category, category));
    }

    if (search && search.trim() !== "") {
        conditions.push(ilike(transaction.description, `%${search}%`));
    }

    return db
        .select()
        .from(transaction)
        .where(and(...conditions))
        .orderBy(desc(transaction.date));
}

export async function getCategoryData(userId: string, type: TransactionType = "expense") {
    const result = await db
        .select({
            category: transaction.category,
            total: sql<string>`COALESCE(SUM(${transaction.amount}), 0)`,
        })
        .from(transaction)
        .where(
            and(
                eq(transaction.userId, userId),
                eq(transaction.type, type),
                gte(transaction.date, startOfMonth(new Date())),
                lte(transaction.date, endOfMonth(new Date()))
            )
        )
        .groupBy(transaction.category)
        .orderBy(desc(sql`SUM(${transaction.amount})`));

    return result.map((r) => ({
        name: r.category,
        value: Number(r.total),
    }));
}
